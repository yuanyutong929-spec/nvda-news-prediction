# NVDA News and Intraday Direction Prediction

Final four-model experiment for the Morgan project. We test whether news improves
NVDA next-15-minute close-to-close direction forecasts beyond market information.

Both news and market bars came from Alpaca. This package starts from the processed
modeling table. Data acquisition, original raw articles and FinBERT inference scripts
are outside this package. No API credentials are required to run this stage.

## Quick start

Use Python 3.11 or 3.12. Open a terminal in this repository folder.

~~~bash
python -m pip install -r requirements.txt
python src/summarize_results.py --results results/reference
~~~

The second command checks stored predictions against accuracy, ROC-AUC and confusion
matrices, then regenerates the aggregate result tables.

Run all four models and all four feature groups:

~~~bash
python src/train_models.py --workers 2
python src/summarize_results.py --results results/rerun
~~~

Start with one combination:

~~~bash
python src/train_models.py --models LR --groups M3 --workers 1
~~~

Model identifiers are LR, RF, SVM and LSTM. Feature groups are M0 to M3.
The --data and --output arguments accept alternative paths. Each selected
combination overwrites its own files in the output folder on rerun.
The script validates the fixed 26,434-row dataset and its target convention.
Using another dataset requires an explicitly revised experiment and split.
Use one or two workers for an initial laptop run.

## Repository contents

| Path | Purpose |
| --- | --- |
| src/train_models.py | Shared data processing, time-series tuning and all four model entry points |
| src/lstm_numpy.py | Single-layer LSTM, backpropagation through time and Adam |
| src/summarize_results.py | Validate predictions and aggregate results |
| data/nvda_model_dataset_slim.csv | Exact 26,434-row, 41-column processed input |
| results/reference | Preserved final experiment outputs |
| results/rerun | Default destination for newly computed outputs |
| requirements.txt | Numerical dependencies |
| .gitignore | Excludes local credentials, environments and regenerated runs |

## Research design

At each prediction time, the completed bar and historical news features predict
whether the next close exceeds the current close. Up is 1; unchanged/down is 0.
Every target gap in this dataset is 15 minutes. Future returns create and verify
the label and are excluded from model inputs.

| Input group | Information | Feature count |
| --- | --- | ---: |
| M0 | Market | 18 |
| M1 | Market and sentiment | 30 |
| M2 | Market and attention | 30 |
| M3 | Market, sentiment and attention | 42 |

Sentiment contains mean positive/neutral/negative FinBERT probabilities and
negative-score dispersion over backward windows of 15/30/60 minutes.
Attention includes news counts, sources, presence, duplication and unusual coverage.
FinBERT probabilities describe text tone, not stock-move probabilities.

The supplied CSV contains 34 original features and auxiliary fields. The script
derives eight further market features: return lags 3/4, sums over 3/5 observations
and their difference, five-observation price momentum, and RSI14 low/high flags.
New lag and rolling features restart at time gaps. Existing indicators come from
the processed input. Source code lists every input column.

## Time-series validation

The final 3,966 rows form the test period, from June 12 to December 31, 2025.
The preceding 22,468 rows form four chronological blocks of 5,617 observations.

| Fold | Train blocks | Validation block | Train rows after boundary gap |
| --- | --- | --- | ---: |
| 1 | A | B | 5,616 |
| 2 | A+B | C | 11,233 |
| 3 | A+B+C | D | 16,850 |

One row is removed from the end of each training segment to keep its label
endpoint strictly before the next validation/test prediction time.
Imputation medians and scaling parameters are fitted within each training fold.
Select the candidate with the largest mean validation balanced accuracy.
The earlier grid entry breaks an exact tie.

Final refitting uses 22,467 pre-test rows. An eight-step LSTM has 22,460 eligible
training targets. Every model predicts the same 3,966 test targets.
There are 192 fold-level fits and 16 final fits in a complete run.

## Hyperparameters

| Model | Search | Fixed settings |
| --- | --- | --- |
| LR | C = 0.01, 0.1, 1, 10 | L2, max_iter=3000 |
| RF | depth = 4/10; leaf = 5/30 | 100 trees, balanced class weights, seed 42 |
| SVM | C = 0.1/1; gamma multiplier = 0.3/1 | 500 Nyström components, LinearSVC, seed 42 |
| LSTM | steps = 4/8; hidden = 16/32 | dense 16, dropout 0.2, Adam 0.001, batch 256, 4 epochs, seed 42 |

SVM approximates an RBF kernel using Nyström features. Gamma equals the
selected multiplier divided by feature count and training-feature variance.
AUC uses its decision scores.

The NumPy LSTM reads sequential observations, then applies dropout, a
16-unit ReLU dense layer, dropout and a binary output. Sequence windows can cross
session boundaries. Four fixed epochs and one seed do not establish convergence
or seed stability. Running the script learns the weights anew; serialized
trained models are not included.

## Final reported results

M0–M3 entries are test accuracy in percent.

| Model | M0 | M1 | M2 | M3 | M3 train | M3 test AUC |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| LR | 48.74 | 49.77 | 49.67 | 49.87 | 51.84 | 0.496879 |
| SVM | 49.82 | 48.89 | 49.02 | 50.15 | 53.38 | 0.501814 |
| RF | 49.34 | 49.80 | 48.89 | 50.63 | 66.87 | 0.500228 |
| LSTM | 50.38 | 50.53 | 50.38 | 50.88 | 53.84 | 0.500040 |

Predicting the training-majority class, non-up, scores 50.03% on the test.
M3 gains over M0 range from 0.33 to 1.29 percentage points. All paired gain
intervals include zero. LSTM gains 20 correct calls, with an approximate
95% interval of -1.42 to +2.47 percentage points.

The summary script resamples entire New York trading dates 5,000 times.
Intervals are pointwise, without multiple-comparison correction, and do not
preserve dependence across days. Three chronological subperiods evaluate the
same fixed model. Every input group is tuned separately.

The test period had already been inspected in earlier experiments.
Results are exploratory and do not establish reliable prediction or trading
profitability. Later untouched data, news-coverage subgroup checks, other
horizons and longer LSTM training are proposed follow-up experiments.

## How to inspect individual results

| Example file | Contents |
| --- | --- |
| cv_M3_LSTM.csv | Four candidates × three validation folds |
| metrics_M3_LSTM.csv | Train/Test metrics and selected parameters |
| pred_M3_LSTM.csv | Timestamp, actual label, predicted label and score |
| all_metrics.csv | 32 Train/Test rows across 16 combinations |
| all_validation.csv | 192 fold records |
| news_gain.csv | M0-relative gains, uncertainty intervals, three segment gains |

Metric files include Accuracy, Precision, Recall, F1, Balanced_Accuracy,
ROC_AUC and TN/FP/FN/TP. Values are proportions; multiply by 100 for percentages.
Prediction scores are probabilities for LR/RF/LSTM and decision values for SVM.

## Team workflow and GitHub upload

1. Read Final reported results for the numbers used in the final poster.
2. Open all_metrics.csv and compare Train/Test rows to discuss in-sample and out-of-sample performance.
3. Filter all_validation.csv by Model and Group to inspect hyperparameter selection.
4. Start with the single LR/M3 command before running every model.
5. Extract this package. Upload the contents of the nvda-news-prediction folder to the repository root, including src, data, results and README.md.
6. This package starts with processed features. Acquisition and FinBERT inference scripts are outside its scope.
7. Both original data sources are Alpaca. No API keys are needed for these training commands.
8. A private repository is suitable for initial team collaboration. The README appears on the repository home page.

## Reference

Akyildirim, E., Goncu, A., & Sensoy, A. (2021).
Prediction of cryptocurrency returns using machine learning.
Annals of Operations Research, 297, 3–36.
https://doi.org/10.1007/s10479-020-03575-y

The added indicators and subperiod checks are adapted to NVDA.
The cited study used cryptocurrencies and different target conventions.
