"""Recalculate metrics and compare news models with their market-only counterpart."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, confusion_matrix, roc_auc_score

def summarize(folder):
    metrics = []
    validation = []
    comparisons = []
    for path in sorted(folder.glob("metrics_M*_*.csv")):
        group, model = path.stem.split("_")[1:]
        observed = pd.read_csv(path)
        predictions = pd.read_csv(folder / f"pred_{group}_{model}.csv")
        expected = observed.loc[observed.Split == "Test"].iloc[0]
        actual = predictions.actual
        predicted = predictions.prediction
        np.testing.assert_allclose(accuracy_score(actual, predicted), expected.Accuracy)
        np.testing.assert_allclose(roc_auc_score(actual, predictions.score), expected.ROC_AUC)
        np.testing.assert_array_equal(
            confusion_matrix(actual, predicted, labels=[0, 1]).ravel(),
            expected[["TN", "FP", "FN", "TP"]].astype(int).to_numpy(),
        )
        if len(predictions) != 3966:
            raise ValueError(f"Unexpected test length in {path}")
        metrics.append(observed)
        validation.append(pd.read_csv(folder / f"cv_{group}_{model}.csv"))
        baseline_path = folder / f"pred_M0_{model}.csv"
        if not baseline_path.exists():
            continue
        baseline = pd.read_csv(baseline_path)
        pd.testing.assert_frame_equal(predictions[["time", "actual"]], baseline[["time", "actual"]])
        correct = predicted.eq(actual).astype(int)
        gains = correct - baseline.prediction.eq(actual).astype(int)
        dates = pd.to_datetime(predictions.time, utc=True).dt.tz_convert("America/New_York").dt.date
        by_day = gains.groupby(dates).agg(["sum", "size"]).to_numpy()
        rng = np.random.default_rng(42)
        samples = by_day[rng.integers(len(by_day), size=(5000, len(by_day)))].sum(axis=1)
        lower, upper = np.quantile(samples[:, 0] / samples[:, 1], [.025, .975])
        row = dict(Model=model, Group=group, Accuracy=correct.mean(),
                   Gain_vs_M0=gains.mean(), CI_low=lower, CI_high=upper)
        for segment, indices in enumerate(np.array_split(np.arange(len(gains)), 3), 1):
            row[f"Segment_{segment}_gain"] = gains.iloc[indices].mean()
        comparisons.append(row)
    if not metrics:
        raise ValueError(f"No completed runs found in {folder}")
    pd.concat(metrics).to_csv(folder / "all_metrics.csv", index=False)
    pd.concat(validation).to_csv(folder / "all_validation.csv", index=False)
    pd.DataFrame(comparisons).to_csv(folder / "news_gain.csv", index=False)
    print(f"Validated {len(metrics)} model/input combinations in {folder}")

if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=root / "results/reference")
    summarize(parser.parse_args().results)
