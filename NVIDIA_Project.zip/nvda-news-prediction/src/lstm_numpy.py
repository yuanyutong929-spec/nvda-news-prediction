"""Single-layer LSTM, dense ReLU and binary classifier, trained with Adam/BPTT."""
import numpy as np
from scipy.special import expit

class LSTM:
    def __init__(self, features, hidden, steps, epochs=4, dropout=.2, seed=42):
        self.rng = np.random.default_rng(seed)
        self.steps, self.epochs, self.dropout = steps, epochs, dropout
        self.h = hidden
        def weights(n, m):
            return self.rng.normal(0, 1 / np.sqrt(n), (n, m)).astype('f')
        self.w = [weights(features+hidden,4*hidden), np.zeros(4*hidden,'f'),
                  weights(hidden,16), np.zeros(16,'f'),weights(16,1),np.zeros(1,'f')]
        self.w[1][hidden:2*hidden] = 1

    def mask(self, x, train):
        if train:
            return (self.rng.random(x.shape) >= self.dropout).astype('f')/(1-self.dropout)
        return 1

    def forward(self, X, ids, train=False):
        W,b,V,a,U,d = self.w
        h = np.zeros((len(ids),self.h),'f')
        c = np.zeros_like(h)
        cache = []
        for offset in reversed(range(self.steps)):
            z = np.concatenate((X[ids-offset], h),axis=1)
            i,f,o,g = np.split(z@W+b,4,axis=1)
            i,f,o,g = expit(i),expit(f),expit(o),np.tanh(g)
            prior = c
            c = prior*f+i*g
            tc = np.tanh(c)
            h = o*tc
            if train:
                cache.append((z,i,f,o,g,prior,tc))
        mh = self.mask(h,train)
        last = h*mh
        dense = np.maximum(last@V+a,0)
        md = self.mask(dense,train)
        out = dense*md
        return expit(out@U+d).ravel(), (cache,last,mh,dense,md,out)

    def gradients(self, X, ids, y):
        p,(cache,last,mh,dense,md,out) = self.forward(X,ids,True)
        error = ((p-y[ids])/len(ids)).astype('f')[:,None]
        W,_,V,_,U,_ = self.w
        da = (error@U.T)*md*(dense>0)
        dh = (da@V.T)*mh
        dc = np.zeros_like(dh)
        dW = np.zeros_like(W)
        db = np.zeros(W.shape[1],'f')
        for z,i,f,o,g,prev,tc in reversed(cache):
            dc += dh*o*(1-tc**2)
            gate = np.concatenate((dc*g*i*(1-i), dc*prev*f*(1-f),
                                   dh*tc*o*(1-o), dc*i*(1-g**2)),axis=1)
            dW += z.T@gate
            db += gate.sum(axis=0)
            dh = gate@W[-self.h:].T
            dc = dc*f
        return [dW,db,last.T@da,da.sum(axis=0),out.T@error,error.sum(axis=0)]

    def fit(self, X, y):
        ids = np.arange(self.steps-1,len(X))
        m,v = ([np.zeros_like(w) for w in self.w] for _ in range(2))
        t = 0
        for _ in range(self.epochs):
            self.rng.shuffle(ids)
            for start in range(0,len(ids),256):
                t += 1
                for j,g in enumerate(self.gradients(X,ids[start:start+256],y)):
                    m[j] = .9*m[j]+.1*g
                    v[j] = .999*v[j]+.001*g*g
                    self.w[j] -= .001*(m[j]/(1-.9**t))/(np.sqrt(v[j]/(1-.999**t))+1e-8)
        return self

    def score_rows(self,X,ids):
        return np.concatenate([self.forward(X,ids[j:j+512])[0] for j in range(0,len(ids),512)])
