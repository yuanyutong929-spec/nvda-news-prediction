"""Train the four NVDA classifiers with chronological hyperparameter selection."""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ[key]='1'
import json
import argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.kernel_approximation import Nystroem
from sklearn.svm import LinearSVC
from sklearn.pipeline import make_pipeline
from sklearn.metrics import (accuracy_score,balanced_accuracy_score,roc_auc_score,precision_score,
                             recall_score,f1_score,confusion_matrix)
from lstm_numpy import LSTM

market='return_15m return_lag1 return_lag2 range_pct vwap_deviation volume_log trade_count_log rsi_14 macd macd_hist'.split()
market += ['ret_lag3','ret_lag4','sum3','sum5','sum5_minus_sum3','momentum5','rsi14_low','rsi14_high']
sent=[f'{k}_{w}m' for w in (15,30,60) for k in ('positive_prob','neutral_prob','negative_prob','negative_prob_std')]
attention=[f'{k}_{w}m' for w in (15,30,60) for k in ('news_count','source_count')]+['has_news_15m','has_news_30m','has_news_60m','log_news_count_60m','duplicate_ratio_60m','attention_surprise']
features=dict(M0=market,M1=market+sent,M2=market+attention,M3=market+sent+attention)
grids={
    'LR':[dict(C=c) for c in (.01,.1,1,10)],
    'RF':[dict(depth=d,leaf=l) for d in (4,10) for l in (5,30)],
    'SVM':[dict(C=c,gamma_multiplier=g) for c in (.1,1) for g in (.3,1)],
    'LSTM':[dict(steps=s,hidden=h) for s in (4,8) for h in (16,32)]}

def metrics(y,p,s):
    tn,fp,fn,tp=confusion_matrix(y,p,labels=[0,1]).ravel()
    return dict(Accuracy=accuracy_score(y,p),Balanced_Accuracy=balanced_accuracy_score(y,p),
                ROC_AUC=roc_auc_score(y,s), Precision=precision_score(y,p,zero_division=0),
                Recall=recall_score(y,p,zero_division=0),F1=f1_score(y,p,zero_division=0),TN=tn,FP=fp,FN=fn,TP=tp, N=len(y))

def run(job):
    file,group,kind,output_dir=job
    df=pd.read_csv(file).sort_values('prediction_time_utc').reset_index(drop=True)
    # Restart intraday features at every gap in the supplied 15-minute observations.
    t=pd.to_datetime(df.prediction_time_utc,utc=True)
    segment=t.diff().ne(pd.Timedelta(minutes=15)).cumsum()
    ret=df.return_15m.groupby(segment)
    for lag in (3,4):
        df[f'ret_lag{lag}']=ret.shift(lag)
    for window in (3,5):
        df[f'sum{window}']=ret.transform(lambda x:x.rolling(window).sum())
    df['sum5_minus_sum3']=df.sum5-df.sum3
    df['momentum5']=df.close-df.close.groupby(segment).shift(5)
    for name, flag in [('low',df.rsi_14<20),('high',df.rsi_14>80)]:
        df['rsi14_'+name]=flag.astype(float).where(df.rsi_14.notna())
    dates=pd.to_datetime(df.prediction_time_utc,utc=True)
    y=df.target_up.to_numpy()
    assert dates.is_monotonic_increasing and dates.is_unique and df.target_valid.all()
    assert np.array_equal(y,(df.future_return_15m>0).astype(int)) and df.future_return_15m.notna().all()
    n=len(df)
    assert n==26434 and df.next_bar_gap_minutes.eq(15).all()
    test_start=int(n*.70)+int(n*.15)
    # The 1-bar embargo prevents a training label from reaching the first validation timestamp.
    bounds=np.linspace(0,test_start,5,dtype=int)
    records=[]
    params=grids[kind]
    trials=np.zeros((len(params),3))
    result=[]
    output=Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    for fold,(start,end) in enumerate(list(zip(bounds[1:-1],bounds[2:]))+[(test_start,n)]):
        train_end=start-1
        assert dates.iloc[train_end-1]+pd.Timedelta(minutes=15)<dates.iloc[start]
        pre=make_pipeline(SimpleImputer(strategy='median',keep_empty_features=True),StandardScaler())
        raw=df[features[group]]
        pre.fit(raw.iloc[:train_end])
        X=pre.transform(raw.iloc[:end]).astype('f')
        ids=np.arange(start,end)
        selected=[int(trials.mean(axis=1).argmax())] if fold==3 else range(len(params))
        for idx in selected:
            p=params[idx]
            if kind=='LSTM':
                model=LSTM(X.shape[1],**p).fit(X[:train_end],y[:train_end])
                score=lambda rows:model.score_rows(X,rows)
                cutoff=.5
            else:
                if kind=='LR':
                    model=LogisticRegression(**p,max_iter=3000)
                elif kind=='RF':
                    model=RandomForestClassifier(n_estimators=100,max_depth=p['depth'],min_samples_leaf=p['leaf'],class_weight='balanced',random_state=42,n_jobs=1)
                else:
                    gamma=p['gamma_multiplier']/(X.shape[1]*np.var(X[:train_end]))
                    model=make_pipeline(Nystroem(kernel='rbf',gamma=float(gamma),n_components=500,random_state=42),LinearSVC(C=p['C'],dual=False,max_iter=10000,random_state=42))
                model.fit(X[:train_end],y[:train_end])
                score=lambda rows:model.decision_function(X[rows]) if kind=='SVM' else model.predict_proba(X[rows])[:,1]
                cutoff=0 if kind=='SVM' else .5
            s=score(ids)
            pred=(s>=cutoff).astype(int)
            if fold<3:
                m=metrics(y[ids],pred,s)
                trials[idx,fold]=m['Balanced_Accuracy']
                records.append(dict(Model=kind,Group=group,Candidate=idx,Params=json.dumps(p),Fold=fold+1,TrainRows=train_end,ValidationStart=str(dates.iloc[start]),ValidationEnd=str(dates.iloc[end-1]),**m))
            else:
                tr=np.arange(p.get('steps',1)-1,train_end)
                ts=score(tr)
                for label,stats in [('Train',metrics(y[tr],ts>=cutoff,ts)),('Test',metrics(y[ids],pred,s))]:
                    result.append(dict(Model=kind,Group=group,Split=label,Params=json.dumps(p),CV_BA=trials[idx].mean(),**stats))
                pd.DataFrame(dict(time=dates.iloc[ids],actual=y[ids],prediction=pred,score=s)).to_csv(output/f'pred_{group}_{kind}.csv',index=False)
    pd.DataFrame(records).to_csv(output/f'cv_{group}_{kind}.csv',index=False)
    pd.DataFrame(result).to_csv(output/f'metrics_{group}_{kind}.csv',index=False)
    print(group,kind,result[-1]['Accuracy'],flush=True)


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=root / "data/nvda_model_dataset_slim.csv")
    parser.add_argument("--output", type=Path, default=root / "results/rerun")
    parser.add_argument("--models", nargs="+", choices=list(grids), default=list(grids))
    parser.add_argument("--groups", nargs="+", choices=list(features), default=list(features))
    parser.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be at least 1")
    if not args.data.is_file():
        parser.error(f"Dataset does not exist: {args.data}")
    jobs = [(args.data, group, model, args.output)
            for model in args.models for group in args.groups]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        list(pool.map(run, jobs))

if __name__ == "__main__":
    main()
