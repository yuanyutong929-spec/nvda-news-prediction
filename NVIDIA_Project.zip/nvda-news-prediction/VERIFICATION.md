# Verification

- Parsed every Python source successfully.
- Recalculated accuracy, ROC-AUC and confusion counts from all 16 archived prediction files.
- Re-ran all four M3 models through the documented CLI.
- Compared all M3 predictions, selected metrics and candidate validation records with the archived experiment. Numerical values matched with absolute and relative tolerances of 1e-10.
- Reruns of M0–M2 were outside this packaging check; their stored predictions were validated.
- Checked packaged Python sources for credential assignments.
- Largest file is the processed dataset, approximately 10.4 MiB.
- Tested on the provided Linux runtime. Windows commands are documented but have not been executed on a Windows machine.
