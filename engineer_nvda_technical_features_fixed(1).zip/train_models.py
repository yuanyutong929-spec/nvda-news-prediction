from __future__ import annotations

from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd

from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    balanced_accuracy_score,
)

# ============================================================
# NVDA 15-minute direction prediction: rebuilt training script
# Uses the finalized feature-engineered dataset as its sole input.
# ============================================================

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "output"
OUT.mkdir(parents=True, exist_ok=True)

DATA_CANDIDATES = [
    OUT / "nvda_model_dataset_final.csv",
    ROOT / "nvda_model_dataset_final.csv",
    ROOT / "data" / "nvda_model_dataset_final.csv",
]

RESULTS_FILE = OUT / "nvda_model_comparison.csv"
PREDICTIONS_FILE = OUT / "nvda_test_predictions.csv"
SPLIT_FILE = OUT / "nvda_train_val_test_split_summary.csv"
FEATURES_FILE = OUT / "nvda_model_feature_sets.json"

RANDOM_STATE = 42
TRAIN_RATIO = 0.70
VAL_RATIO = 0.15
TEST_RATIO = 0.15

# Optional LSTM sequence length. LSTM is skipped cleanly if TensorFlow
# is not installed; the three scikit-learn models still run.
LSTM_SEQUENCE_LENGTH = 8

# Features known at the prediction time. The target and future-derived
# columns are deliberately never included in these lists.
TECHNICAL_FEATURES = [
    "return_15m",
    "log_return_15m",
    "return_lag1",
    "return_lag2",
    "return_lag3",
    "return_lag4",
    "range_pct",
    "volatility_4",
    "close_open_return",
    "vwap_deviation",
    "volume_log",
    "trade_count_log",
]

SENTIMENT_FEATURES = [
    "positive_prob_15m", "neutral_prob_15m", "negative_prob_15m",
    "negative_prob_std_15m",
    "positive_prob_30m", "neutral_prob_30m", "negative_prob_30m",
    "negative_prob_std_30m",
    "positive_prob_60m", "neutral_prob_60m", "negative_prob_60m",
    "negative_prob_std_60m",
]

INTENSITY_FEATURES = [
    "news_count_15m", "source_count_15m",
    "news_count_30m", "source_count_30m",
    "news_count_60m", "source_count_60m",
    "has_news_15m", "has_news_30m", "has_news_60m",
    "log_news_count_60m", "duplicate_ratio_60m",
    "attention_surprise",
]

FEATURE_SETS = {
    "M0_market_only": TECHNICAL_FEATURES,
    "M1_market_plus_sentiment": TECHNICAL_FEATURES + SENTIMENT_FEATURES,
    "M2_market_plus_news_intensity": TECHNICAL_FEATURES + INTENSITY_FEATURES,
    "M3_market_sentiment_intensity": (
        TECHNICAL_FEATURES + SENTIMENT_FEATURES + INTENSITY_FEATURES
    ),
}

FORBIDDEN_FEATURES = {
    "target_up",
    "future_return_15m",
    "target_valid",
    "next_bar_gap_minutes",
    "prediction_time_utc",
    "timestamp_utc",
    "bar_time_utc",
    "bar_time_ny",
}


def locate_dataset() -> Path:
    for path in DATA_CANDIDATES:
        if path.exists():
            return path
    paths = "\n".join(str(p) for p in DATA_CANDIDATES)
    raise FileNotFoundError(
        "找不到最终建模数据集 nvda_model_dataset_final.csv。\n"
        "请把它放在项目的 output 文件夹中。\n已检查：\n" + paths
    )


def require_columns(df: pd.DataFrame, cols: list[str], label: str) -> None:
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"{label} 缺少必要列：{missing}")


def load_and_validate(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)

    required = [
        "timestamp_utc", "prediction_time_utc", "target_up",
        "target_valid", "next_bar_gap_minutes", "close",
    ]
    require_columns(df, required, "最终建模数据集")

    df["timestamp_utc"] = pd.to_datetime(
        df["timestamp_utc"], utc=True, errors="coerce"
    )
    df["prediction_time_utc"] = pd.to_datetime(
        df["prediction_time_utc"], utc=True, errors="coerce"
    )
    bad_timestamp_rows = int(
        df["timestamp_utc"].isna().sum()
        + df["prediction_time_utc"].isna().sum()
    )
    if bad_timestamp_rows:
        raise ValueError(
            f"时间戳解析失败共 {bad_timestamp_rows} 项。"
            "请先修复输入数据，脚本不会静默删除这些行。"
        )

    if df["timestamp_utc"].duplicated().any():
        raise ValueError("timestamp_utc 存在重复值，不能安全地进行时间切分。")

    df = df.sort_values("prediction_time_utc").reset_index(drop=True)

    # Some dataset revisions contain news counts but omit one or more has_news
    # indicators. Derive these deterministic flags from counts rather than
    # failing or silently using a different definition.
    for window in (15, 30, 60):
        count_col = f"news_count_{window}m"
        flag_col = f"has_news_{window}m"
        if flag_col not in df.columns and count_col in df.columns:
            df[flag_col] = (
                pd.to_numeric(df[count_col], errors="coerce").fillna(0) > 0
            ).astype(int)

    # Guard against mismatched prediction-time semantics.
    expected_prediction_time = df["timestamp_utc"] + pd.Timedelta(minutes=15)
    mismatch = df["prediction_time_utc"].ne(expected_prediction_time)
    if mismatch.any():
        examples = df.loc[
            mismatch, ["timestamp_utc", "prediction_time_utc"]
        ].head(5)
        raise ValueError(
            "prediction_time_utc 并非 timestamp_utc + 15 分钟。"
            "请先统一预测时点定义。示例：\n"
            + examples.to_string(index=False)
        )

    # Only rows whose next bar is exactly 15 minutes later are valid for
    # the stated one-bar-ahead target. Exclude invalid targets before splitting.
    valid_flag = df["target_valid"].astype(str).str.lower().isin(
        ["true", "1", "1.0"]
    )
    gap = pd.to_numeric(df["next_bar_gap_minutes"], errors="coerce")
    target = pd.to_numeric(df["target_up"], errors="coerce")
    eligible = valid_flag & gap.eq(15) & target.isin([0, 1])

    excluded = int((~eligible).sum())
    df = df.loc[eligible].copy()
    df["target_up"] = pd.to_numeric(df["target_up"]).astype(int)

    if df.empty:
        raise ValueError(
            "过滤 target_valid、next_bar_gap_minutes=15 后没有可训练样本。"
        )
    if df["target_up"].nunique() != 2:
        raise ValueError("有效样本中的 target_up 只有一个类别，无法进行二分类。")

    df.attrs["input_rows"] = int(len(pd.read_csv(path)))
    df.attrs["excluded_invalid_target_rows"] = excluded
    return df


def check_feature_sets(df: pd.DataFrame) -> dict[str, list[str]]:
    checked = {}
    for name, requested in FEATURE_SETS.items():
        require_columns(df, requested, f"特征组 {name}")
        forbidden_overlap = set(requested) & FORBIDDEN_FEATURES
        if forbidden_overlap:
            raise AssertionError(
                f"特征组 {name} 包含禁止输入的字段：{sorted(forbidden_overlap)}"
            )
        checked[name] = list(requested)
    return checked


def chronological_split(df: pd.DataFrame):
    n = len(df)
    train_end = int(n * TRAIN_RATIO)
    val_end = int(n * (TRAIN_RATIO + VAL_RATIO))
    train = df.iloc[:train_end].copy()
    val = df.iloc[train_end:val_end].copy()
    test = df.iloc[val_end:].copy()

    if min(len(train), len(val), len(test)) == 0:
        raise ValueError("训练/验证/测试切分后存在空数据集。")

    summary = pd.DataFrame([
        {
            "split": "train",
            "rows": len(train),
            "start_prediction_time_utc": train["prediction_time_utc"].min(),
            "end_prediction_time_utc": train["prediction_time_utc"].max(),
            "positive_rate": train["target_up"].mean(),
        },
        {
            "split": "validation",
            "rows": len(val),
            "start_prediction_time_utc": val["prediction_time_utc"].min(),
            "end_prediction_time_utc": val["prediction_time_utc"].max(),
            "positive_rate": val["target_up"].mean(),
        },
        {
            "split": "test",
            "rows": len(test),
            "start_prediction_time_utc": test["prediction_time_utc"].min(),
            "end_prediction_time_utc": test["prediction_time_utc"].max(),
            "positive_rate": test["target_up"].mean(),
        },
    ])
    return train, val, test, summary


def metric_row(y_true, pred, prob, feature_set, model_name, split_sizes):
    auc = np.nan
    if prob is not None and len(np.unique(y_true)) == 2:
        try:
            auc = roc_auc_score(y_true, prob)
        except ValueError:
            pass
    return {
        "feature_set": feature_set,
        "model": model_name,
        "train_rows": split_sizes["train"],
        "validation_rows": split_sizes["validation"],
        "test_rows": split_sizes["test"],
        "accuracy": accuracy_score(y_true, pred),
        "balanced_accuracy": balanced_accuracy_score(y_true, pred),
        "precision_up": precision_score(y_true, pred, zero_division=0),
        "recall_up": recall_score(y_true, pred, zero_division=0),
        "f1_up": f1_score(y_true, pred, zero_division=0),
        "roc_auc": auc,
    }


def make_classical_models():
    return {
        "LogisticRegression": LogisticRegression(
            max_iter=3000, class_weight="balanced", random_state=RANDOM_STATE
        ),
        "RandomForest": RandomForestClassifier(
            n_estimators=300,
            min_samples_leaf=5,
            class_weight="balanced_subsample",
            random_state=RANDOM_STATE,
            n_jobs=-1,
        ),
        "SVM_RBF": SVC(
            kernel="rbf",
            C=1.0,
            probability=True,
            class_weight="balanced",
            random_state=RANDOM_STATE,
        ),
    }


def run_classical_models(train, val, test, feature_sets):
    results, prediction_frames = [], []
    split_sizes = {
        "train": len(train), "validation": len(val), "test": len(test)
    }

    for feature_set_name, features in feature_sets.items():
        # Numeric conversion; infinite values become missing and are imputed
        # using medians fitted on the training split only.
        X_train = train[features].apply(pd.to_numeric, errors="coerce")
        X_val = val[features].apply(pd.to_numeric, errors="coerce")
        X_test = test[features].apply(pd.to_numeric, errors="coerce")
        X_train = X_train.replace([np.inf, -np.inf], np.nan)
        X_val = X_val.replace([np.inf, -np.inf], np.nan)
        X_test = X_test.replace([np.inf, -np.inf], np.nan)

        # Entirely missing columns in train are not learnable. Stop and report
        # them rather than silently dropping a different set in each split.
        all_missing = X_train.columns[X_train.isna().all()].tolist()
        if all_missing:
            raise ValueError(
                f"{feature_set_name} 中以下特征在训练集全部缺失：{all_missing}。"
                "请检查数据生成流程或从该特征组中明确移除。"
            )

        y_train = train["target_up"].astype(int)
        y_test = test["target_up"].astype(int)

        for model_name, estimator in make_classical_models().items():
            pipe = Pipeline([
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler()),
                ("model", estimator),
            ])
            pipe.fit(X_train, y_train)
            pred = pipe.predict(X_test)
            prob = pipe.predict_proba(X_test)[:, 1]

            results.append(
                metric_row(y_test, pred, prob, feature_set_name, model_name, split_sizes)
            )
            pred_df = test[
                ["timestamp_utc", "prediction_time_utc", "close", "target_up"]
            ].copy()
            pred_df["feature_set"] = feature_set_name
            pred_df["model"] = model_name
            pred_df["prediction_up"] = pred
            pred_df["probability_up"] = prob
            prediction_frames.append(pred_df)

    return results, prediction_frames


def run_optional_lstm(train, val, test, feature_sets):
    """Run LSTM if TensorFlow is installed; otherwise return an explicit skip note."""
    try:
        import tensorflow as tf
        from tensorflow.keras import Sequential
        from tensorflow.keras.layers import Input, LSTM, Dense, Dropout
        from tensorflow.keras.callbacks import EarlyStopping
    except Exception as exc:
        return [], [], f"跳过 LSTM：当前环境无法导入 TensorFlow（{exc.__class__.__name__}）。"

    results, prediction_frames = [], []
    seq_len = LSTM_SEQUENCE_LENGTH

    # Fit each feature set's imputer/scaler on training data only.
    for feature_set_name, features in feature_sets.items():
        parts = [train, val, test]
        arrays = []
        medians = train[features].apply(pd.to_numeric, errors="coerce")
        medians = medians.replace([np.inf, -np.inf], np.nan)
        all_missing = medians.columns[medians.isna().all()].tolist()
        if all_missing:
            return results, prediction_frames, (
                f"跳过 LSTM：{feature_set_name} 训练集全缺失特征：{all_missing}"
            )

        imputer = SimpleImputer(strategy="median")
        scaler = StandardScaler()
        x_train_raw = imputer.fit_transform(medians)
        x_train = scaler.fit_transform(x_train_raw)

        for part in parts[1:]:
            x_raw = part[features].apply(pd.to_numeric, errors="coerce")
            x_raw = x_raw.replace([np.inf, -np.inf], np.nan)
            arrays.append(scaler.transform(imputer.transform(x_raw)))

        # Sequence windows are created within each split separately so no
        # sequence crosses train/validation/test boundaries.
        x_train_seq, y_train_seq = make_sequences(
            x_train, train["target_up"].to_numpy(dtype=int), seq_len
        )
        x_val = arrays[0]
        x_test = arrays[1]
        x_val_seq, y_val_seq = make_sequences(
            x_val, val["target_up"].to_numpy(dtype=int), seq_len
        )
        x_test_seq, y_test_seq = make_sequences(
            x_test, test["target_up"].to_numpy(dtype=int), seq_len
        )
        if min(len(x_train_seq), len(x_val_seq), len(x_test_seq)) == 0:
            continue

        tf.keras.utils.set_random_seed(RANDOM_STATE)
        model = Sequential([
            Input(shape=(seq_len, len(features))),
            LSTM(32, return_sequences=False),
            Dropout(0.2),
            Dense(16, activation="relu"),
            Dense(1, activation="sigmoid"),
        ])
        model.compile(
            optimizer="adam",
            loss="binary_crossentropy",
            metrics=[tf.keras.metrics.AUC(name="auc")],
        )
        callback = EarlyStopping(
            monitor="val_loss", patience=4, restore_best_weights=True
        )
        model.fit(
            x_train_seq, y_train_seq,
            validation_data=(x_val_seq, y_val_seq),
            epochs=30,
            batch_size=128,
            callbacks=[callback],
            verbose=0,
            shuffle=False,
        )

        prob = model.predict(x_test_seq, verbose=0).ravel()
        pred = (prob >= 0.5).astype(int)
        sizes = {
            "train": len(x_train_seq),
            "validation": len(x_val_seq),
            "test": len(x_test_seq),
        }
        results.append(
            metric_row(y_test_seq, pred, prob, feature_set_name, "LSTM", sizes)
        )

        # Sequence target is aligned to the final row of each sequence.
        aligned_test = test.iloc[seq_len - 1:].copy()
        pred_df = aligned_test[
            ["timestamp_utc", "prediction_time_utc", "close", "target_up"]
        ].copy()
        pred_df["feature_set"] = feature_set_name
        pred_df["model"] = "LSTM"
        pred_df["prediction_up"] = pred
        pred_df["probability_up"] = prob
        prediction_frames.append(pred_df)

    return results, prediction_frames, "LSTM 已运行。"


def make_sequences(x, y, seq_len):
    if len(x) <= seq_len:
        return np.empty((0, seq_len, x.shape[1])), np.empty((0,), dtype=int)
    xs, ys = [], []
    for end in range(seq_len - 1, len(x)):
        xs.append(x[end - seq_len + 1:end + 1])
        ys.append(y[end])
    return np.asarray(xs, dtype=np.float32), np.asarray(ys, dtype=int)


def main():
    data_path = locate_dataset()
    print(f"读取最终建模数据：{data_path}")
    df = load_and_validate(data_path)
    feature_sets = check_feature_sets(df)

    train, val, test, split_summary = chronological_split(df)
    split_summary.to_csv(SPLIT_FILE, index=False, encoding="utf-8-sig")
    FEATURES_FILE.write_text(
        json.dumps(feature_sets, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"输入行数：{df.attrs.get('input_rows', '未知'):,}")
    print(f"排除无效目标行数：{df.attrs.get('excluded_invalid_target_rows', '未知'):,}")
    print(f"有效样本数：{len(df):,}")
    print("\n时间顺序切分：")
    print(split_summary.to_string(index=False))

    classical_results, classical_predictions = run_classical_models(
        train, val, test, feature_sets
    )
    lstm_results, lstm_predictions, lstm_note = run_optional_lstm(
        train, val, test, feature_sets
    )

    all_results = classical_results + lstm_results
    all_predictions = classical_predictions + lstm_predictions
    if not all_results:
        raise RuntimeError("没有成功运行任何模型。")

    results_df = pd.DataFrame(all_results).sort_values(
        ["feature_set", "roc_auc"], ascending=[True, False], na_position="last"
    )
    predictions_df = pd.concat(all_predictions, ignore_index=True)

    results_df.to_csv(RESULTS_FILE, index=False, encoding="utf-8-sig")
    predictions_df.to_csv(PREDICTIONS_FILE, index=False, encoding="utf-8-sig")

    print("\n测试集模型比较：")
    print(results_df.to_string(index=False))
    print(f"\n已保存结果：\n{RESULTS_FILE}\n{PREDICTIONS_FILE}")
    print(f"切分摘要：{SPLIT_FILE}")
    print(f"特征组定义：{FEATURES_FILE}")
    print(lstm_note)
    print(
        "\n注意：验证集目前只用于 LSTM early stopping；经典模型没有用验证集调参。"
        "所有结果都是时间顺序测试集结果，不应直接视为交易策略收益。"
    )


if __name__ == "__main__":
    main()
