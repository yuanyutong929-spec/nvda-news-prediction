from pathlib import Path
import numpy as np
import pandas as pd

"""
NVDA 15-minute technical feature engineering (corrected final candidate).

IMPORTANT:
- Base model dataset: nvda_model_dataset_news_checked.csv
- Stock source: nvda_stock_15min_clean.csv
- Keeps all rows and all non-technical columns from the news_checked dataset.
- Recalculates the original 12 technical features plus RSI(14) and MACD(12,26,9) from stock OHLCV data, then merges by timestamp.
- Does not train a model, impute technical missing values, or delete model rows.

Recommended project layout:
project/
  data/nvda_stock_15min_clean.csv
  output/nvda_model_dataset_news_checked.csv
  engineer_nvda_technical_features_final.py

The script also searches the project root if the CSVs are stored there.
"""

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "output"

def find_input(filename, preferred_dir):
    candidates = [
        preferred_dir / filename,
        ROOT / filename,
        OUT_DIR / filename,
        DATA_DIR / filename,
    ]
    for path in candidates:
        if path.exists():
            return path
    checked = "\n".join(str(p) for p in candidates)
    raise FileNotFoundError(
        f"找不到输入文件：{filename}\n已检查以下位置：\n{checked}"
    )

STOCK_FILE = find_input("nvda_stock_15min_clean.csv", DATA_DIR)
MODEL_FILE = find_input("nvda_model_dataset_news_checked.csv", OUT_DIR)
OUTPUT_FILE = OUT_DIR / "nvda_model_dataset_final.csv"
QUALITY_FILE = OUT_DIR / "nvda_technical_feature_quality_final.csv"
REPORT_FILE = OUT_DIR / "nvda_technical_continuity_report_final.txt"

BAR_MINUTES = 15
TECHNICAL_COLS = [
    "return_15m", "log_return_15m",
    "return_lag1", "return_lag2", "return_lag3", "return_lag4",
    "range_pct", "volatility_4", "close_open_return",
    "vwap_deviation", "volume_log", "trade_count_log",
    "rsi_14", "macd", "macd_signal", "macd_hist",
]

def require_columns(df, columns, filename):
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise ValueError(
            f"{filename} 缺少必要字段：{missing}\n"
            f"实际字段：{df.columns.tolist()}"
        )

def main():
    print(f"读取股票数据：{STOCK_FILE}")
    stock_raw = pd.read_csv(STOCK_FILE)
    print(f"读取已完成新闻缺失处理的数据：{MODEL_FILE}")
    model_raw = pd.read_csv(MODEL_FILE)

    stock_required = [
        "timestamp_utc", "open", "high", "low", "close",
        "volume", "vwap", "trade_count"
    ]
    require_columns(stock_raw, stock_required, STOCK_FILE.name)
    require_columns(model_raw, ["timestamp_utc"], MODEL_FILE.name)

    stock_input_rows = len(stock_raw)
    model_input_rows = len(model_raw)

    stock = stock_raw.copy()
    model = model_raw.copy()
    stock["timestamp_utc"] = pd.to_datetime(
        stock["timestamp_utc"], utc=True, errors="coerce"
    )
    model["timestamp_utc"] = pd.to_datetime(
        model["timestamp_utc"], utc=True, errors="coerce"
    )

    invalid_stock_times = int(stock["timestamp_utc"].isna().sum())
    invalid_model_times = int(model["timestamp_utc"].isna().sum())

    if invalid_stock_times:
        raise ValueError(
            f"股票文件有 {invalid_stock_times} 行 timestamp_utc 无法解析。"
            "请先检查原始文件，不自动删除。"
        )
    if invalid_model_times:
        raise ValueError(
            f"news_checked 文件有 {invalid_model_times} 行 timestamp_utc 无法解析。"
            "为避免静默丢样本，脚本停止。"
        )

    if stock["timestamp_utc"].duplicated().any():
        examples = stock.loc[
            stock["timestamp_utc"].duplicated(keep=False), "timestamp_utc"
        ].head().astype(str).tolist()
        raise ValueError(f"股票数据时间戳重复，例如：{examples}")
    if model["timestamp_utc"].duplicated().any():
        examples = model.loc[
            model["timestamp_utc"].duplicated(keep=False), "timestamp_utc"
        ].head().astype(str).tolist()
        raise ValueError(f"news_checked 数据时间戳重复，例如：{examples}")

    stock = stock.sort_values("timestamp_utc").reset_index(drop=True)
    model = model.sort_values("timestamp_utc").reset_index(drop=True)

    numeric_cols = ["open", "high", "low", "close", "volume", "vwap", "trade_count"]
    for col in numeric_cols:
        stock[col] = pd.to_numeric(stock[col], errors="coerce")

    # A return is valid only when the current bar is exactly 15 minutes
    # after the preceding row. Overnight/session gaps are not treated as
    # ordinary 15-minute intervals.
    gap_minutes = stock["timestamp_utc"].diff().dt.total_seconds() / 60
    consecutive = gap_minutes.eq(BAR_MINUTES)

    prev_close = stock["close"].shift(1)
    valid_prices = stock["close"].gt(0) & prev_close.gt(0)
    simple_return = stock["close"].div(prev_close).sub(1)
    log_return = np.log(stock["close"].div(prev_close))
    simple_return = simple_return.where(consecutive & valid_prices)
    log_return = log_return.where(consecutive & valid_prices)

    feat = pd.DataFrame({"timestamp_utc": stock["timestamp_utc"]})
    feat["return_15m"] = simple_return
    feat["log_return_15m"] = log_return

    # Lag k means the return observed k bars before the current row.
    # Keep it only if the intervals linking that historical return to the
    # current bar form a continuous 15-minute chain.
    for lag in range(1, 5):
        lagged = simple_return.shift(lag)
        required_intervals = lag + 1
        chain_ok = (
            consecutive.astype("int8")
            .rolling(required_intervals, min_periods=required_intervals)
            .sum()
            .eq(required_intervals)
        )
        feat[f"return_lag{lag}"] = lagged.where(chain_ok)

    feat["range_pct"] = (
        (stock["high"] - stock["low"]) /
        stock["close"].where(stock["close"].ne(0))
    )
    feat["close_open_return"] = (
        (stock["close"] - stock["open"]) /
        stock["open"].where(stock["open"].ne(0))
    )
    feat["vwap_deviation"] = (
        (stock["close"] - stock["vwap"]) /
        stock["vwap"].where(stock["vwap"].ne(0))
    )

    # Four adjacent 15-minute returns; ddof=1 gives sample standard deviation.
    vol = simple_return.rolling(window=4, min_periods=4).std(ddof=1)
    chain4 = (
        consecutive.astype("int8")
        .rolling(4, min_periods=4)
        .sum()
        .eq(4)
    )
    feat["volatility_4"] = vol.where(chain4)

    feat["volume_log"] = np.log1p(stock["volume"].where(stock["volume"].ge(0)))
    feat["trade_count_log"] = np.log1p(
        stock["trade_count"].where(stock["trade_count"].ge(0))
    )

    # RSI(14) and MACD(12, 26, 9).
    # IMPORTANT: calculate chronologically across trading sessions. A normal
    # overnight/weekend closure is not a reason to restart these recursive
    # indicators; only the initial warm-up period should be missing.
    # This differs from 15-minute returns/lags, where a 15-minute continuity
    # check is required to define an ordinary adjacent-bar return.
    close = stock["close"].where(stock["close"].gt(0))

    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)

    # Wilder-style RSI(14). First 14 price changes are the warm-up period.
    avg_gain = gain.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    avg_loss = loss.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi_values = 100 - (100 / (1 + rs))
    rsi_values = rsi_values.mask(avg_loss.eq(0) & avg_gain.gt(0), 100)
    rsi_values = rsi_values.mask(
        avg_loss.eq(0) & avg_gain.eq(0) & avg_gain.notna(), 50
    )

    # Standard MACD: EMA(12) - EMA(26), signal EMA(9) of MACD.
    ema12 = close.ewm(span=12, adjust=False, min_periods=12).mean()
    ema26 = close.ewm(span=26, adjust=False, min_periods=26).mean()
    macd_values = ema12 - ema26
    macd_signal_values = macd_values.ewm(
        span=9, adjust=False, min_periods=9
    ).mean()
    macd_hist_values = macd_values - macd_signal_values

    feat["rsi_14"] = rsi_values
    feat["macd"] = macd_values
    feat["macd_signal"] = macd_signal_values
    feat["macd_hist"] = macd_hist_values

    # Drop stale versions of these technical fields only; retain all news
    # sentiment fields, has_news flags, labels, and other model columns.
    stale_technical_cols = [c for c in TECHNICAL_COLS if c in model.columns]
    if stale_technical_cols:
        model = model.drop(columns=stale_technical_cols)

    result = model.merge(
        feat,
        on="timestamp_utc",
        how="left",
        validate="one_to_one",
        indicator=True,
    )
    unmatched = int(result["_merge"].ne("both").sum())
    result = result.drop(columns=["_merge"])

    # Guardrails: preserve the model dataset's row count and timestamp set.
    if len(result) != model_input_rows:
        raise AssertionError(
            f"合并前后行数不一致：输入 {model_input_rows}，输出 {len(result)}"
        )
    if result["timestamp_utc"].duplicated().any():
        raise AssertionError("合并后 timestamp_utc 出现重复。")

    quality_rows = []
    for col in TECHNICAL_COLS:
        s = pd.to_numeric(result[col], errors="coerce")
        quality_rows.append({
            "feature": col,
            "rows": len(result),
            "non_missing": int(s.notna().sum()),
            "missing": int(s.isna().sum()),
            "missing_pct": round(float(s.isna().mean() * 100), 4),
            "min": float(s.min()) if s.notna().any() else np.nan,
            "median": float(s.median()) if s.notna().any() else np.nan,
            "max": float(s.max()) if s.notna().any() else np.nan,
        })
    quality = pd.DataFrame(quality_rows)

    gap_distribution = gap_minutes.value_counts(dropna=False).sort_index()
    # Explicit diagnostics: stock intervals and model-to-stock timestamp coverage.
    # The first row has no preceding row, so its diff is NaN and must not
    # be counted as either a 15-minute interval or a non-15-minute interval.
    has_previous_row = gap_minutes.notna()
    exact_15m_mask = gap_minutes.eq(BAR_MINUTES)
    non_15m_mask = has_previous_row & ~exact_15m_mask
    interval_counts = {
        "stock_rows": int(len(stock)),
        "adjacent_intervals": int(has_previous_row.sum()),
        "exact_15m_intervals": int(exact_15m_mask.sum()),
        "non_15m_intervals": int(non_15m_mask.sum()),
        "model_rows": int(len(model)),
        "model_timestamps_matched": int(len(model) - unmatched),
        "model_timestamps_unmatched": int(unmatched),
    }

    report_lines = [
        "NVDA 技术特征工程最终候选版：连续性与合并检查",
        "=" * 60,
        f"股票输入文件：{STOCK_FILE}",
        f"建模输入文件：{MODEL_FILE}",
        f"股票原始行数：{stock_input_rows:,}",
        f"news_checked 原始行数：{model_input_rows:,}",
        f"股票时间戳无效行数：{invalid_stock_times:,}",
        f"建模数据时间戳无效行数：{invalid_model_times:,}",
        f"输出行数：{len(result):,}",
        f"未匹配到股票技术特征的建模行数：{unmatched:,}",
        f"股票相邻记录总间隔数（应为股票行数减 1）：{interval_counts['adjacent_intervals']:,}",
        f"股票相邻间隔恰好 15 分钟的数量：{interval_counts['exact_15m_intervals']:,}",
        f"股票相邻间隔不是 15 分钟的数量（不含首行 NaN）：{interval_counts['non_15m_intervals']:,}",
        f"间隔分类核对（15 分钟 + 非 15 分钟，应等于相邻间隔总数）：{interval_counts['exact_15m_intervals'] + interval_counts['non_15m_intervals']:,}",
        f"建模数据时间戳匹配成功数量：{interval_counts['model_timestamps_matched']:,}",
        f"建模数据时间戳未匹配数量：{interval_counts['model_timestamps_unmatched']:,}",
        "",
        "股票相邻记录时间间隔分布（分钟；首行 NaN 表示第一条记录没有前序记录）：",
        gap_distribution.to_string(),
        "",
        "技术特征缺失率：",
        quality[["feature", "non_missing", "missing", "missing_pct"]].to_string(index=False),
        "",
        "检查说明：",
        "1. 以 nvda_model_dataset_news_checked.csv 为基础，保留其新闻情感、has_news 标记、标签及其他字段。",
        "2. 只重算并替换 16 个技术特征（原 12 个 + RSI(14) + MACD(12,26,9) 的三条输出），不填补技术特征缺失值。",
        "3. 不删除建模行；未匹配的行会保留并在报告中计数。",
        "4. 时间间隔统计排除第一行没有前序记录产生的 NaN；15 分钟间隔数与非 15 分钟间隔数之和应等于相邻间隔总数。",
        "5. 每个 15 分钟收益率要求当前记录与上一条记录间隔恰好 15 分钟；滞后收益和滚动波动率还要求所需历史区间连续。",
        "6. 本脚本不训练模型，也不能单独证明新闻情感聚合没有未来信息泄漏。",
        "7. 训练前仍需排除标签、未来收益、目标有效性和未来间隔等字段，避免将它们作为输入。",
    ]

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    result.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")
    quality.to_csv(QUALITY_FILE, index=False, encoding="utf-8-sig")
    REPORT_FILE.write_text("\n".join(report_lines), encoding="utf-8")

    print("\n完成。")
    print(f"输入建模行数：{model_input_rows:,}")
    print(f"输出建模行数：{len(result):,}")
    print(f"未匹配技术特征行数：{unmatched:,}")
    print("\n技术特征缺失统计：")
    print(quality[["feature", "non_missing", "missing", "missing_pct"]].to_string(index=False))
    print(f"\n最终候选建模数据：{OUTPUT_FILE}")
    print(f"技术特征质量报告：{QUALITY_FILE}")
    print(f"连续性报告：{REPORT_FILE}")
    print("\n请先检查质量报告；此文件是最终候选版本，尚需完成数据验收后再用于训练。")

if __name__ == "__main__":
    main()
