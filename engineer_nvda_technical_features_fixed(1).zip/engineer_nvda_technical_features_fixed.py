from pathlib import Path
import numpy as np
import pandas as pd

"""NVDA 15-minute technical feature engineering (no model training).

Expected project layout:
  project_root/data/nvda_stock_15min_clean.csv
  project_root/output/nvda_model_dataset.csv

Outputs:
  project_root/output/nvda_model_dataset_with_technical_features.csv
  project_root/output/nvda_technical_feature_quality.csv

All features use the current completed bar and past bars only.
"""

ROOT = Path(__file__).resolve().parent
STOCK_FILE = ROOT / "data" / "nvda_stock_15min_clean.csv"
MODEL_FILE = ROOT / "output" / "nvda_model_dataset.csv"
OUTPUT_FILE = ROOT / "output" / "nvda_model_dataset_with_technical_features.csv"
QUALITY_FILE = ROOT / "output" / "nvda_technical_feature_quality.csv"
BAR_MINUTES = 15


def require_columns(df, columns, filename):
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise ValueError(f"{filename} 缺少字段：{missing}\n实际字段：{df.columns.tolist()}")


def main():
    if not STOCK_FILE.exists():
        raise FileNotFoundError(f"找不到股票原始文件：{STOCK_FILE}")
    if not MODEL_FILE.exists():
        raise FileNotFoundError(f"找不到建模数据集：{MODEL_FILE}；请先运行 build_model_dataset_fixed.py")

    stock = pd.read_csv(STOCK_FILE)
    model = pd.read_csv(MODEL_FILE)
    require_columns(stock, [
        "timestamp_utc", "open", "high", "low", "close", "volume", "vwap",
        "trade_count", "return_15m", "log_return_15m", "range_pct",
        "close_open_return", "vwap_deviation"
    ], STOCK_FILE.name)
    require_columns(model, ["timestamp_utc"], MODEL_FILE.name)

    stock["timestamp_utc"] = pd.to_datetime(stock["timestamp_utc"], utc=True, errors="coerce")
    model["timestamp_utc"] = pd.to_datetime(model["timestamp_utc"], utc=True, errors="coerce")
    stock = (stock.dropna(subset=["timestamp_utc"])
                  .sort_values("timestamp_utc")
                  .drop_duplicates("timestamp_utc", keep="last")
                  .reset_index(drop=True))

    numeric_cols = [
        "open", "high", "low", "close", "volume", "vwap", "trade_count",
        "return_15m", "log_return_15m", "range_pct", "close_open_return", "vwap_deviation"
    ]
    for col in numeric_cols:
        stock[col] = pd.to_numeric(stock[col], errors="coerce")

    # consecutive[i] is True only when bar i is exactly 15 minutes after bar i-1.
    gap_minutes = stock["timestamp_utc"].diff().dt.total_seconds() / 60
    consecutive = gap_minutes.eq(BAR_MINUTES)

    features = stock[[
        "timestamp_utc", "return_15m", "log_return_15m", "range_pct",
        "close_open_return", "vwap_deviation"
    ]].copy()

    # Lag 1 = previous bar's return; lag 4 = return from four bars earlier.
    # Check only historical/current gaps (never future gaps).
    # Lag 1–4: use historical returns only, and verify every required bar interval.
    for lag in range(1, 5):
        lagged_return = stock["return_15m"].shift(lag)

        # The lagged return itself also needs a valid interval.
        # For lag=1, verify 2 consecutive intervals; for lag=4, verify 5.
        required_intervals = lag + 1
        chain_ok = (
            consecutive
            .rolling(window=required_intervals, min_periods=required_intervals)
            .sum()
            .eq(required_intervals)
        )

        features[f"return_lag{lag}"] = lagged_return.where(chain_ok)
    # Standard deviation of the current and previous 3 bar returns,
    # only when all four return intervals are consecutive 15-minute bars.
    rolling_vol = stock["return_15m"].rolling(window=4, min_periods=4).std(ddof=1)
    chain_4_ok = consecutive.rolling(window=4, min_periods=4).sum().eq(4)
    features["volatility_4"] = rolling_vol.where(chain_4_ok)

    volume = stock["volume"].where(stock["volume"] >= 0)
    trades = stock["trade_count"].where(stock["trade_count"] >= 0)
    features["volume_log"] = np.log1p(volume)
    features["trade_count_log"] = np.log1p(trades)

    previous_volume = stock["volume"].shift(1)
    volume_change = stock["volume"] / previous_volume.replace(0, np.nan) - 1
    features["volume_change"] = volume_change.where(consecutive)

    if features["timestamp_utc"].duplicated().any():
        raise RuntimeError("特征表 timestamp_utc 重复，停止合并。")
    if model["timestamp_utc"].duplicated().any():
        raise RuntimeError("建模数据集 timestamp_utc 重复，停止合并。")

    feature_names = [c for c in features.columns if c != "timestamp_utc"]
    overlap = [c for c in feature_names if c in model.columns]
    if overlap:
        model = model.drop(columns=overlap)

    result = model.merge(features, on="timestamp_utc", how="left", validate="one_to_one")

    technical_cols = [
        "return_15m", "log_return_15m", "range_pct", "close_open_return", "vwap_deviation",
        "return_lag1", "return_lag2", "return_lag3", "return_lag4",
        "volatility_4", "volume_log", "trade_count_log"
    ]
    quality = pd.DataFrame({
        "feature": technical_cols,
        "non_missing": [int(result[c].notna().sum()) for c in technical_cols],
        "missing": [int(result[c].isna().sum()) for c in technical_cols],
        "min": [float(result[c].min()) if result[c].notna().any() else np.nan for c in technical_cols],
        "median": [float(result[c].median()) if result[c].notna().any() else np.nan for c in technical_cols],
        "max": [float(result[c].max()) if result[c].notna().any() else np.nan for c in technical_cols],
    })

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")
    quality.to_csv(QUALITY_FILE, index=False, encoding="utf-8-sig")

    print("\n===== 技术特征工程完成 =====")
    print(f"原始股票行数：{len(stock):,}")
    print(f"输入建模数据行数：{len(model):,}")
    print(f"输出行数：{len(result):,}")
    print("\n特征缺失情况：")
    print(quality[["feature", "non_missing", "missing"]].to_string(index=False))
    print(f"\n建模数据：{OUTPUT_FILE}")
    print(f"特征质量报告：{QUALITY_FILE}")
    print("注意：future_return_15m、target_up、target_valid、next_bar_gap_minutes 不得作为模型输入特征。")


if __name__ == "__main__":
    main()
