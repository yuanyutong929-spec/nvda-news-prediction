from __future__ import annotations

"""Build a reduced NVDA modeling dataset without modifying the original final CSV.

Default input priority:
  1) output/nvda_model_dataset_final.csv
  2) nvda_model_dataset_final.csv
  3) nvda_model_dataset_final(4).csv
  4) data/nvda_model_dataset_final.csv

Output files are written to output/ with new names. The source final dataset is
read-only and is never overwritten by this script.

Run in PyCharm:
    python build_nvda_slim_dataset.py

Or specify paths:
    python build_nvda_slim_dataset.py --input "nvda_model_dataset_final(4).csv"
    python build_nvda_slim_dataset.py --input "path/to/final.csv" --output "output/nvda_model_dataset_slim.csv"
"""

import argparse
from pathlib import Path
from itertools import combinations

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
DEFAULT_OUTPUT_DIR = ROOT / "output"

# Reduced, pre-selected feature set.
# Keep one simple return instead of both simple and log returns;
# keep lag 1/2 only; omit close_open_return and volatility_4 from the first slim model;
# retain RSI, MACD line, and MACD histogram (macd_signal is linearly redundant).
TECHNICAL_FEATURES = [
    "return_15m",
    "return_lag1",
    "return_lag2",
    "range_pct",
    "vwap_deviation",
    "volume_log",
    "trade_count_log",
    "rsi_14",
    "macd",
    "macd_hist",
]

SENTIMENT_FEATURES = [
    "positive_prob_15m", "neutral_prob_15m", "negative_prob_15m",
    "negative_prob_std_15m",
    "positive_prob_30m", "neutral_prob_30m", "negative_prob_30m",
    "negative_prob_std_30m",
    "positive_prob_60m", "neutral_prob_60m", "negative_prob_60m",
    "negative_prob_std_60m",
]

INTENSITY_FEATURES = [
    "news_count_15m", "source_count_15m",
    "news_count_30m", "source_count_30m",
    "news_count_60m", "source_count_60m",
    "has_news_15m", "has_news_30m", "has_news_60m",
    "log_news_count_60m", "duplicate_ratio_60m",
    "attention_surprise",
]

# Keep these columns for sorting, target validation, and prediction-result inspection.
# They are NOT model input features.
METADATA_AND_TARGET_COLUMNS = [
    "timestamp_utc",
    "prediction_time_utc",
    "close",
    "next_bar_gap_minutes",
    "future_return_15m",
    "target_up",
    "target_valid",
]

STD_AND_COUNT = {
    "negative_prob_std_15m": "news_count_15m",
    "negative_prob_std_30m": "news_count_30m",
    "negative_prob_std_60m": "news_count_60m",
}


def locate_input(user_input: str | None) -> Path:
    if user_input:
        path = Path(user_input).expanduser()
        if not path.is_absolute():
            path = (ROOT / path).resolve()
        if not path.exists():
            raise FileNotFoundError(f"指定的输入文件不存在：{path}")
        return path.resolve()

    candidates = [
        ROOT / "output" / "nvda_model_dataset_final.csv",
        ROOT / "nvda_model_dataset_final.csv",
        ROOT / "nvda_model_dataset_final(4).csv",
        ROOT / "data" / "nvda_model_dataset_final.csv",
    ]
    for path in candidates:
        if path.exists():
            return path.resolve()

    checked = "\n".join(str(p) for p in candidates)
    raise FileNotFoundError(
        "没有找到最终数据集。请将 final CSV 放在项目 output 文件夹，"
        "或者使用 --input 指定路径。\n已检查：\n" + checked
    )


def require_columns(df: pd.DataFrame, columns: list[str]) -> None:
    missing = [col for col in columns if col not in df.columns]
    if missing:
        raise ValueError(
            "输入 final 数据集缺少以下必要列，未生成精简数据集：\n"
            + "\n".join(missing)
        )


def main() -> None:
    parser = argparse.ArgumentParser(description="创建独立的 NVDA 精简建模数据集")
    parser.add_argument("--input", default=None, help="输入 final CSV 路径；不填写则自动查找")
    parser.add_argument(
        "--output",
        default=None,
        help="精简数据集输出路径；默认 output/nvda_model_dataset_slim.csv",
    )
    args = parser.parse_args()

    input_path = locate_input(args.input)
    output_path = (
        Path(args.output).expanduser()
        if args.output
        else DEFAULT_OUTPUT_DIR / "nvda_model_dataset_slim.csv"
    )
    if not output_path.is_absolute():
        output_path = (ROOT / output_path).resolve()
    else:
        output_path = output_path.resolve()

    # Explicit protection: never let the output target the original input file.
    if output_path == input_path:
        raise ValueError(
            "安全停止：输出路径与输入 final 数据集相同。请使用新文件名，"
            "例如 output/nvda_model_dataset_slim.csv。"
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    audit_path = output_path.with_name(output_path.stem + "_column_audit.csv")
    corr_path = output_path.with_name(output_path.stem + "_high_correlations.csv")
    report_path = output_path.with_name(output_path.stem + "_build_report.txt")

    print(f"读取原始数据（只读，不会覆盖）：{input_path}")
    df = pd.read_csv(input_path, low_memory=False)
    input_rows, input_cols = df.shape

    required = list(dict.fromkeys(
        METADATA_AND_TARGET_COLUMNS
        + TECHNICAL_FEATURES
        + SENTIMENT_FEATURES
        + INTENSITY_FEATURES
    ))
    require_columns(df, required)

    # Validate/sort timestamps without changing the original field values unnecessarily.
    for col in ["timestamp_utc", "prediction_time_utc"]:
        parsed = pd.to_datetime(df[col], utc=True, errors="coerce")
        if parsed.isna().any():
            bad = int(parsed.isna().sum())
            raise ValueError(f"{col} 有 {bad} 个无法解析的时间戳；请先检查输入数据。")
        df[f"__parsed_{col}"] = parsed

    if df["__parsed_timestamp_utc"].duplicated().any():
        dup_n = int(df["__parsed_timestamp_utc"].duplicated().sum())
        raise ValueError(f"timestamp_utc 存在 {dup_n} 个重复时间戳，停止创建精简数据集。")

    df = df.sort_values("__parsed_prediction_time_utc").reset_index(drop=True)

    # Ensure has_news indicators agree with the corresponding news counts.
    for window in (15, 30, 60):
        count_col = f"news_count_{window}m"
        flag_col = f"has_news_{window}m"
        numeric_count = pd.to_numeric(df[count_col], errors="coerce")
        df[flag_col] = np.where(numeric_count.notna(), (numeric_count > 0).astype(int), np.nan)

    # A dispersion statistic is undefined when there are no articles in the window.
    # Encode that case as 0, while retaining news_count/has_news to disambiguate it.
    std_fill_counts: dict[str, int] = {}
    for std_col, count_col in STD_AND_COUNT.items():
        count = pd.to_numeric(df[count_col], errors="coerce")
        no_news = count.eq(0)
        before = df[std_col].isna()
        df.loc[no_news, std_col] = 0.0
        std_fill_counts[std_col] = int((no_news & before).sum())

        # If there are articles but their standard deviation is missing, leave it NaN
        # so the audit can expose it and the model's train-only imputer can handle it.

    # Retain only metadata/target + the chosen model feature columns.
    selected_columns = list(dict.fromkeys(
        METADATA_AND_TARGET_COLUMNS
        + TECHNICAL_FEATURES
        + SENTIMENT_FEATURES
        + INTENSITY_FEATURES
    ))
    slim = df[selected_columns].copy()

    # Convert model-input columns to numeric. Invalid numeric strings become NaN;
    # no rows are deleted just because a feature is missing.
    model_features = TECHNICAL_FEATURES + SENTIMENT_FEATURES + INTENSITY_FEATURES
    for col in model_features:
        slim[col] = pd.to_numeric(slim[col], errors="coerce")
        slim[col] = slim[col].replace([np.inf, -np.inf], np.nan)

    # Check target fields but do NOT delete invalid rows here; the training script
    # should apply target_valid / next_bar_gap_minutes filtering consistently.
    target_numeric = pd.to_numeric(slim["target_up"], errors="coerce")
    valid_flag = slim["target_valid"].astype(str).str.strip().str.lower().isin(
        ["true", "1", "1.0"]
    )
    gap = pd.to_numeric(slim["next_bar_gap_minutes"], errors="coerce")
    eligible = valid_flag & gap.eq(15) & target_numeric.isin([0, 1])

    # Save the reduced dataset, keeping all source rows for auditability.
    slim.to_csv(output_path, index=False, encoding="utf-8-sig")

    # Feature-level missingness audit (after the deliberate no-news std treatment).
    audit_rows = []
    roles = {}
    for c in TECHNICAL_FEATURES:
        roles[c] = "technical_feature"
    for c in SENTIMENT_FEATURES:
        roles[c] = "sentiment_feature"
    for c in INTENSITY_FEATURES:
        roles[c] = "news_intensity_feature"
    for c in METADATA_AND_TARGET_COLUMNS:
        roles[c] = "metadata_or_target_not_model_input"

    for col in selected_columns:
        series = slim[col]
        audit_rows.append({
            "column": col,
            "role": roles.get(col, "other"),
            "dtype": str(series.dtype),
            "missing_count": int(series.isna().sum()),
            "missing_pct": round(float(series.isna().mean() * 100), 4),
            "unique_non_missing": int(series.nunique(dropna=True)),
        })
    pd.DataFrame(audit_rows).to_csv(audit_path, index=False, encoding="utf-8-sig")

    # Record strongly correlated pairs among retained technical inputs.
    corr = slim[TECHNICAL_FEATURES].corr(numeric_only=True)
    corr_rows = []
    for col_a, col_b in combinations(TECHNICAL_FEATURES, 2):
        value = corr.loc[col_a, col_b]
        if pd.notna(value) and abs(float(value)) >= 0.80:
            corr_rows.append({
                "feature_1": col_a,
                "feature_2": col_b,
                "pearson_correlation": float(value),
                "absolute_correlation": abs(float(value)),
                "note": "仅用于冗余筛查；相关性不等于没有预测价值",
            })
    pd.DataFrame(
        corr_rows,
        columns=["feature_1", "feature_2", "pearson_correlation", "absolute_correlation", "note"],
    ).to_csv(corr_path, index=False, encoding="utf-8-sig")

    missing_after = slim[model_features].isna().sum()
    non_news_std_missing = {}
    for std_col, count_col in STD_AND_COUNT.items():
        count = pd.to_numeric(slim[count_col], errors="coerce")
        non_news_std_missing[std_col] = int((slim[std_col].isna() & count.gt(0)).sum())

    lines = [
        "NVDA 精简建模数据集构建报告",
        "=" * 32,
        f"输入文件：{input_path}",
        f"输出文件：{output_path}",
        f"原始数据尺寸：{input_rows:,} 行 × {input_cols} 列",
        f"精简数据尺寸：{slim.shape[0]:,} 行 × {slim.shape[1]} 列",
        f"有效目标候选样本数（target_valid 且下一根间隔 15 分钟且标签为 0/1）：{int(eligible.sum()):,}",
        "",
        "保留技术特征（10）：" + ", ".join(TECHNICAL_FEATURES),
        "保留情感特征（12）：" + ", ".join(SENTIMENT_FEATURES),
        "保留新闻关注度特征（12）：" + ", ".join(INTENSITY_FEATURES),
        "",
        "无新闻窗口中填 0 的标准差缺失数量：",
    ]
    for col, count in std_fill_counts.items():
        lines.append(f"  {col}: {count:,}")
    lines.extend(["", "有新闻但标准差仍缺失的行数（需检查；训练时可由训练集拟合的 imputer 处理）："])
    for col, count in non_news_std_missing.items():
        lines.append(f"  {col}: {count:,}")
    lines.extend(["", "剩余模型特征缺失数量（本脚本不删除样本，也不在全数据上拟合填充值）："])
    for col, count in missing_after.items():
        if count:
            lines.append(f"  {col}: {int(count):,} ({count / len(slim):.2%})")
    lines.extend([
        "",
        f"特征缺失审计：{audit_path}",
        f"保留技术特征高相关组合（|r| >= 0.80）：{corr_path}",
        "注意：原始 final 数据集未被修改。所有非新闻标准差的其他缺失值均保留，",
        "应在训练阶段只使用训练集拟合中位数填补器，避免测试信息泄漏。",
    ])
    report_path.write_text("\n".join(lines), encoding="utf-8")

    print("\n构建完成。原始 final 数据集未被覆盖。")
    print(f"原始数据：{input_rows:,} 行 × {input_cols} 列")
    print(f"精简数据：{slim.shape[0]:,} 行 × {slim.shape[1]} 列")
    print(f"有效目标候选样本：{int(eligible.sum()):,}")
    print(f"精简数据集：{output_path}")
    print(f"列缺失审计：{audit_path}")
    print(f"高相关特征审计：{corr_path}")
    print(f"构建报告：{report_path}")


if __name__ == "__main__":
    main()
