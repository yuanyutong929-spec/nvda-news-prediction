# NVDA News Sentiment + 15-minute Stock Prediction

## Files
- data/nvda_stock_15min_clean.csv
- data/nvda_news_clean.csv
- run_finbert.py: score each news item with FinBERT
- train_models.py: create time-aligned features and compare Logistic Regression / SVM

## Setup (PyCharm Terminal; use the project's Python 3.12 interpreter)
```bash
python -m pip install -r requirements.txt
```

## Run in order
```bash
python run_finbert.py
python train_models.py
```

FinBERT downloads the model from Hugging Face the first time, so the first run requires internet access.
