from pathlib import Path
import numpy as np
import pandas as pd

"""
NVDA 行情特征工程（不训练模型）
输入：
  data/nvda_stock_15min_clean.csv
  output/nvda_model_dataset.csv
输出：
  output/nvda_model_dataset_with_technical_features.csv

说明：
- 不修改原始文件或现有建模数据集。
- 只使用当前已结束 K 线及其历史信息构造行情特征。
- return_15m、log_return_15m、range_pct、close_open_return、
  vwap_deviation 已在股票原始文件中存在，直接沿用。
- 新增 return_lag2 至 return_lag5、volatility_4、
  volume_log、volume_change、trade_count_log。
"""

ROOT = Path(__file__).resolve().parent
STOCK_FILE = ROOT / "data" / "nvda_stock_15min_clean.csv"
MODEL_FILE = ROOT / "output" / "nvda_model_dataset.csv"
OUTPUT_FILE = ROOT / "output" / "nvda_model_dataset_with_technical_features.csv"

BAR_MINUTES = 15


def require_columns(df, columns, filename):
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise ValueError(
            f"{filename} 缺少必要字段：{missing}\n"
            f"实际字段：{df.columns.tolist()}"
        )


def main():
    if not STOCK_FILE.exists():
        raise FileNotFoundError(f"找不到股票原始文件：{STOCK_FILE}")
    if not MODEL_FILE.exists():
        raise FileNotFoundError(
            f"找不到现有建模数据集：{MODEL_FILE}\n"
            "请先运行 build_model_dataset_fixed.py。"
        )

    stock = pd.read_csv(STOCK_FILE)
    model = pd.read_csv(MODEL_FILE)

    require_columns(
        stock,
        [
            "timestamp_utc", "open", "high", "low", "close",
            "volume", "vwap", "trade_count", "return_15m",
            "log_return_15m", "range_pct", "close_open_return",
            "vwap_deviation"
        ],
        STOCK_FILE.name
    )
    require_columns(model, ["timestamp_utc"], MODEL_FILE.name)

    # 统一时间格式并按原始股票 K 线顺序计算特征。
    stock["timestamp_utc"] = pd.to_datetime(
        stock["timestamp_utc"], utc=True, errors="coerce"
    )
    model["timestamp_utc"] = pd.to_datetime(
        model["timestamp_utc"], utc=True, errors="coerce"
    )

    stock = (
        stock.dropna(subset=["timestamp_utc"])
        .sort_values("timestamp_utc")
        .drop_duplicates("timestamp_utc", keep="last")
        .reset_index(drop=True)
    )

    numeric_cols = [
        "open", "high", "low", "close", "volume", "vwap",
        "trade_count", "return_15m", "log_return_15m",
        "range_pct", "close_open_return", "vwap_deviation"
    ]
    for col in numeric_cols:
        stock[col] = pd.to_numeric(stock[col], errors="coerce")

    # 判断当前 K 线与上一条 K 线是否时间连续。
    timestamp_gap = stock["timestamp_utc"].diff().dt.total_seconds().div(60)
    consecutive = timestamp_gap.eq(BAR_MINUTES)

    # 已有的当前 K 线特征：只保留研究所需列。
    features = stock[[
        "timestamp_utc",
        "return_15m",
        "log_return_15m",
        "range_pct",
        "close_open_return",
        "vwap_deviation"
    ]].copy()

    # return_15m 是当前已结束 K 线的收益率。
    # lag2 表示前一根 K 线的收益率，依此类推。
    for lag in range(1, 5):
        lagged = stock["return_15m"].shift(lag)
        # 只有每个所需相邻间隔均为连续 15 分钟时才保留滞后值。
        valid_chain = pd.Series(True, index=stock.index)
        for step in range(lag):
            valid_chain &= consecutive.shift(-step).fillna(False)
        features[f"return_lag{lag + 1}"] = lagged.where(valid_chain)

    # 最近 4 根连续 K 线收益率的样本标准差（不跨越时间缺口）。
    returns = stock["return_15m"]
    rolling_vol = returns.rolling(window=4, min_periods=4).std(ddof=1)
    valid_4 = pd.Series(True, index=stock.index)
    for step in range(4):
        valid_4 &= consecutive.shift(-step).fillna(False)
    features["volatility_4"] = rolling_vol.where(valid_4)

    # 成交量取对数。无效/负值先变成缺失值。
    volume = stock["volume"].where(stock["volume"] >= 0)
    trade_count = stock["trade_count"].where(stock["trade_count"] >= 0)
    features["volume_log"] = np.log1p(volume)
    features["trade_count_log"] = np.log1p(trade_count)

    # 成交量相对上一根连续 K 线的变化率。
    previous_volume = stock["volume"].shift(1)
    volume_change = (stock["volume"] / previous_volume.replace(0, np.nan)) - 1
    features["volume_change"] = volume_change.where(consecutive)

    # 检查时间戳键唯一，再将特征合并到现有建模数据集。
    if features["timestamp_utc"].duplicated().any():
        raise RuntimeError("特征表中出现重复 timestamp_utc，已停止合并。")
    if model["timestamp_utc"].duplicated().any():
        raise RuntimeError("建模数据集中出现重复 timestamp_utc，已停止合并。")

    # 避免已有同名列造成 _x/_y 混乱；以本次从原始股票数据计算的列为准。
    feature_names = [c for c in features.columns if c != "timestamp_utc"]
    overlap = [c for c in feature_names if c in model.columns]
    if overlap:
        model = model.drop(columns=overlap)

    result = model.merge(
        features,
        on="timestamp_utc",
        how="left",
        validate="one_to_one"
    )

    # 质量报告：只统计新增/沿用的行情特征，不进行模型训练。
    technical_cols = [
        "return_15m", "log_return_15m", "range_pct",
        "close_open_return", "vwap_deviation",
        "return_lag2", "return_lag3", "return_lag4", "return_lag5",
        "volatility_4", "volume_log", "volume_change", "trade_count_log"
    ]
    quality = pd.DataFrame({
        "feature": technical_cols,
        "non_missing": [int(result[c].notna().sum()) for c in technical_cols],
        "missing": [int(result[c].isna().sum()) for c in technical_cols],
        "min": [
            float(result[c].min()) if result[c].notna().any() else np.nan
            for c in technical_cols
        ],
        "median": [
            float(result[c].median()) if result[c].notna().any() else np.nan
            for c in technical_cols
        ],
        "max": [
            float(result[c].max()) if result[c].notna().any() else np.nan
            for c in technical_cols
        ],
    })

    result.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")
    quality_file = ROOT / "output" / "nvda_technical_feature_quality.csv"
    quality.to_csv(quality_file, index=False, encoding="utf-8-sig")

    print("\n===== 行情特征工程完成 =====")
    print("原始股票行数：", len(stock))
    print("输入建模数据行数：", len(model))
    print("输出行数：", len(result))
    print("新增/沿用行情特征：", len(technical_cols))
    print("\n特征非空情况：")
    print(quality[["feature", "non_missing", "missing"]].to_string(index=False))
    print("\n输出文件：")
    print(OUTPUT_FILE)
    print(quality_file)
    print("\n未训练模型，未修改原始 CSV 和原建模数据集。")


if __name__ == "__main__":
    main()
