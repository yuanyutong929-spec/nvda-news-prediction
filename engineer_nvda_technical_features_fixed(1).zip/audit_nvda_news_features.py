from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "output"
OUT.mkdir(parents=True, exist_ok=True)


def resolve_file(name: str) -> Path:
    candidates = [OUT / name, ROOT / name, ROOT / "data" / name]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        f"找不到 {name}。请将文件放在项目的 output、项目根目录或 data 文件夹。\n"
        + "\n".join(str(path) for path in candidates)
    )


DATA_FILE = resolve_file("nvda_model_dataset_with_technical_features.csv")
NEWS_FILE = resolve_file("nvda_news_relevance_dedup_audit.csv")
OUT_DATA = OUT / "nvda_model_dataset_news_checked.csv"
OUT_REPORT = OUT / "nvda_news_quality_report.txt"
OUT_WINDOW_REPORT = OUT / "nvda_news_window_quality.csv"
OUT_TIME_AUDIT = OUT / "nvda_news_time_alignment_audit.csv"

WINDOWS = (15, 30, 60)
SCORE_NAMES = ("positive", "neutral", "negative")
SCORE_COLS = ["positive_prob", "neutral_prob", "negative_prob"]


def parse_bool(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False)
    return series.astype(str).str.strip().str.lower().isin(
        {"true", "1", "yes", "y", "t"}
    )


def require_columns(frame: pd.DataFrame, columns: list[str], label: str):
    missing = [column for column in columns if column not in frame.columns]
    if missing:
        raise ValueError(f"{label}缺少字段：{', '.join(missing)}")


def main():
    print(f"读取建模数据：{DATA_FILE}")
    df = pd.read_csv(DATA_FILE, low_memory=False)
    print(f"读取新闻审核数据：{NEWS_FILE}")
    news = pd.read_csv(NEWS_FILE, low_memory=False)

    required_df = ["timestamp_utc", "prediction_time_utc"]
    for window in WINDOWS:
        required_df += [
            f"news_count_{window}m", f"source_count_{window}m",
            f"positive_prob_{window}m", f"neutral_prob_{window}m",
            f"negative_prob_{window}m"
        ]
    require_columns(df, required_df, "建模数据")
    require_columns(
        news,
        ["created_at_utc", "relevance_class", "duplicate_flag",
         "unique_for_attention", *SCORE_COLS],
        "新闻审核表"
    )

    df["timestamp_utc"] = pd.to_datetime(
        df["timestamp_utc"], utc=True, errors="coerce"
    )
    df["prediction_time_utc"] = pd.to_datetime(
        df["prediction_time_utc"], utc=True, errors="coerce"
    )
    news["created_at_utc"] = pd.to_datetime(
        news["created_at_utc"], utc=True, errors="coerce"
    )
    for col in SCORE_COLS:
        news[col] = pd.to_numeric(news[col], errors="coerce")
        news.loc[~news[col].between(0, 1), col] = np.nan

    news["relevance_class_norm"] = (
        news["relevance_class"].fillna("").astype(str).str.strip().str.lower()
    )
    news["duplicate_bool"] = parse_bool(news["duplicate_flag"])
    news["unique_bool"] = parse_bool(news["unique_for_attention"])
    if "source" not in news.columns:
        news["source"] = ""
    news["source_norm"] = news["source"].fillna("").astype(str).str.strip()

    # Match the same selection rule used to build the model dataset:
    # Direct news that are unique-for-attention and not marked as duplicates.
    selected_news = news.loc[
        news["created_at_utc"].notna()
        & news["relevance_class_norm"].eq("direct")
        & news["unique_bool"]
        & ~news["duplicate_bool"]
    ].copy()
    selected_news = selected_news.sort_values("created_at_utc").reset_index(drop=True)

    report = [
        "NVDA 新闻特征质量与时间对齐审计报告",
        "=" * 58,
        f"建模数据行数：{len(df):,}",
        f"新闻审核表行数：{len(news):,}",
        f"可用发布时间的新闻数：{news['created_at_utc'].notna().sum():,}",
        f"用于建模窗口的 Direct 去重新闻数：{len(selected_news):,}",
        f"无效预测时间行数：{df['prediction_time_utc'].isna().sum():,}",
        f"无效 K 线时间行数：{df['timestamp_utc'].isna().sum():,}",
    ]

    report += [
        "",
        "[新闻分类与去重]",
        "相关性分类分布：",
        news["relevance_class"].fillna("<缺失>").astype(str).value_counts().to_string(),
        f"duplicate_flag=True：{news['duplicate_bool'].sum():,}",
        f"unique_for_attention=True：{news['unique_bool'].sum():,}",
        f"实际纳入窗口计算的 Direct 新闻：{len(selected_news):,}",
    ]

    # Verify prediction time equals bar start + 15 minutes.
    valid_times = df["timestamp_utc"].notna() & df["prediction_time_utc"].notna()
    delta_min = (
        df.loc[valid_times, "prediction_time_utc"]
        - df.loc[valid_times, "timestamp_utc"]
    ).dt.total_seconds() / 60
    bad_prediction_delta = int((~np.isclose(delta_min, 15.0)).sum())

    report += [
        "",
        "[预测时点]",
        f"prediction_time_utc 与 timestamp_utc 相差不是 15 分钟的行数：{bad_prediction_delta:,}",
    ]

    # Vectorized per-row window audit. A valid news item must satisfy:
    # prediction_time - window <= created_at < prediction_time.
    # The strict right boundary excludes news timestamped exactly at prediction time.
    usable_pred = df["prediction_time_utc"].notna()
    # Normalize both timestamps to nanoseconds explicitly. Depending on the
    # pandas version/input format, datetime64 may otherwise use microseconds.
    pred_ns = (
        df.loc[usable_pred, "prediction_time_utc"]
        .map(lambda t: t.value)
        .to_numpy(dtype=np.int64)
    )
    news_ns = (
        selected_news["created_at_utc"]
        .map(lambda t: t.value)
        .to_numpy(dtype=np.int64)
    )
    # searchsorted requires the news timestamp array to be sorted ascending.
    news_ns = np.sort(news_ns.copy())
    time_rows = []
    window_rows = []

    if len(news_ns):
        for window in WINDOWS:
            lower_ns = pred_ns - pd.Timedelta(minutes=window).value
            left = np.searchsorted(news_ns, lower_ns, side="left")
            right = np.searchsorted(news_ns, pred_ns, side="left")
            expected_count = right - left

            actual_count = pd.to_numeric(
                df.loc[usable_pred, f"news_count_{window}m"], errors="coerce"
            ).to_numpy()
            count_comparable = np.isfinite(actual_count)
            count_mismatch = count_comparable & (actual_count != expected_count)

            # Check exact boundaries independently.
            at_or_after_prediction = int(
                (selected_news["created_at_utc"] >= df["prediction_time_utc"].max()).sum()
            ) if df["prediction_time_utc"].notna().any() else 0

            time_rows.append({
                "window": f"{window}m",
                "rows_checked": int(usable_pred.sum()),
                "actual_news_count_missing": int(np.isnan(actual_count).sum()),
                "rows_with_count_mismatch": int(count_mismatch.sum()),
                "expected_news_rows_sum": int(expected_count.sum()),
                "actual_news_rows_sum": int(np.nansum(actual_count)),
                "boundary_rule": "[prediction_time-window, prediction_time)",
                "news_at_or_after_max_prediction_time_in_audit_table": at_or_after_prediction,
            })

            window_rows.append({
                "window": f"{window}m",
                "rows": len(df),
                "news_count_missing": int(pd.to_numeric(
                    df[f"news_count_{window}m"], errors="coerce"
                ).isna().sum()),
                "expected_no_news_rows": int((expected_count == 0).sum()),
                "expected_news_rows": int((expected_count > 0).sum()),
                "rows_with_count_mismatch": int(count_mismatch.sum()),
                "source_count_missing": int(pd.to_numeric(
                    df[f"source_count_{window}m"], errors="coerce"
                ).isna().sum()),
            })
    else:
        report.append("警告：筛选后的 Direct 去重新闻为空，无法验证新闻窗口。")

    time_audit = pd.DataFrame(time_rows)
    time_audit.to_csv(OUT_TIME_AUDIT, index=False, encoding="utf-8-sig")
    window_report = pd.DataFrame(window_rows)
    window_report.to_csv(OUT_WINDOW_REPORT, index=False, encoding="utf-8-sig")

    report += ["", "[逐行新闻窗口对齐核查]"]
    if len(time_audit):
        report.append(time_audit.to_string(index=False))
        if (time_audit["rows_with_count_mismatch"] > 0).any():
            report.append(
                "结论：发现新闻数量与重新按发布时间计算的窗口数量不一致。"
                "请勿直接训练；先核对新闻筛选规则、重复新闻规则与窗口构建代码。"
            )
        else:
            report.append(
                "结论：三个窗口的 news_count 均与重新计算结果一致。"
                "这验证了窗口计数与时间边界的一致性，但不能单独证明每条聚合情感的来源完全无泄漏。"
            )

    # Sentiment probability sanity checks and no-news encoding.
    report += ["", "[情感概率与无新闻窗口]"]
    for window in WINDOWS:
        count = pd.to_numeric(df[f"news_count_{window}m"], errors="coerce")
        score_cols = [f"{name}_prob_{window}m" for name in SCORE_NAMES]
        scores = df[score_cols].apply(pd.to_numeric, errors="coerce")
        no_news = count.eq(0) & count.notna()
        has_news = count.gt(0) & count.notna()
        complete = scores.notna().all(axis=1)
        all_missing = scores.isna().all(axis=1)
        sums = scores.sum(axis=1, min_count=3)
        bad_sum = complete & ~np.isclose(sums, 1.0, atol=0.02)
        bad_range = complete & ~((scores >= 0) & (scores <= 1)).all(axis=1)
        report += [
            f"{window}m：news_count 缺失={count.isna().sum():,}；"
            f"无新闻={no_news.sum():,}；有新闻={has_news.sum():,}；"
            f"有新闻但三项情感全缺失={(has_news & all_missing).sum():,}；"
            f"情感概率总和异常={bad_sum.sum():,}；越界={bad_range.sum():,}"
        ]

        # Canonical indicator names, avoiding duplicate *_checked fields.
        indicator = f"has_news_{window}m"
        df[indicator] = has_news.astype("int8")

        # Only encode explicitly empty windows with a neutral prior.
        # A positive count with missing sentiment remains missing and is not hidden.
        df.loc[no_news, score_cols[0]] = 0.0
        df.loc[no_news, score_cols[1]] = 1.0
        df.loc[no_news, score_cols[2]] = 0.0

    # Report duplicate indicators if older columns existed.
    existing_indicators = [c for c in df.columns if c.endswith("_checked") and c.startswith("has_news_")]
    if existing_indicators:
        df = df.drop(columns=existing_indicators)
        report.append(
            "\n已删除旧的重复标记列：" + ", ".join(existing_indicators)
        )

    df.to_csv(OUT_DATA, index=False, encoding="utf-8-sig")

    report += [
        "",
        "[输出文件]",
        f"检查后建模数据：{OUT_DATA}",
        f"窗口质量表：{OUT_WINDOW_REPORT}",
        f"时间对齐审计表：{OUT_TIME_AUDIT}",
        "",
        "处理说明：",
        "1. 使用 Direct + unique_for_attention=True + duplicate_flag=False 的新闻重新计算窗口计数。",
        "2. 新闻窗口采用 [prediction_time-window, prediction_time)，排除恰好在预测时点及之后发布的新闻。",
        "3. 只将 news_count=0 的情感概率编码为正面=0、中性=1、负面=0。",
        "4. 有新闻但情感概率缺失的行不填补，保留以供排查。",
        "5. 统一使用 has_news_15m、has_news_30m、has_news_60m，不保留 *_checked 重复标记。",
        "6. 原始输入文件不被覆盖。",
    ]
    OUT_REPORT.write_text("\n".join(report), encoding="utf-8")

    print("\n新闻质量与时间对齐审计完成。")
    print(f"报告：{OUT_REPORT}")
    print(f"窗口质量表：{OUT_WINDOW_REPORT}")
    print(f"时间对齐审计表：{OUT_TIME_AUDIT}")
    print(f"检查后数据：{OUT_DATA}")
    if len(time_audit) and (time_audit["rows_with_count_mismatch"] > 0).any():
        print("警告：发现窗口计数不一致，请先查看报告，不要直接训练模型。")
    else:
        print("请查看报告中的逐行窗口计数是否一致，再进入模型训练。")


if __name__ == "__main__":
    main()
