from pathlib import Path
import re, html
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)
SCORES_FILE = OUT / "nvda_finbert_probabilities.csv"
STOCK_FILE = DATA / "nvda_stock_15min_clean.csv"

DIRECT_TERMS = [r"\bnvidia\b", r"\bnvda\b", r"\bgeforce\b", r"\bblackwell\b",
                r"\bcuda\b", r"\bh100\b", r"\bh200\b", r"\bgb200\b", r"英伟达"]
INDIRECT_TERMS = [r"\bsemiconductor(s)?\b", r"\bchip(s)?\b", r"\bGPU(s)?\b",
                  r"\bAMD\b", r"\bIntel\b", r"\bTSMC\b", r"\bBroadcom\b",
                  r"\bdata cent(er|re)s?\b", r"\bartificial intelligence\b",
                  r"\bAI infrastructure\b", r"半导体", r"芯片", r"人工智能"]

def norm_text(value):
    if pd.isna(value):
        return ""
    s = html.unescape(str(value)).lower()
    s = re.sub(r"https?://\S+", " ", s)
    s = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()

def main():
    if not SCORES_FILE.exists():
        raise FileNotFoundError(f"找不到 {SCORES_FILE}，请先运行 run_finbert.py。")
    if not STOCK_FILE.exists():
        raise FileNotFoundError(f"找不到 {STOCK_FILE}，请放入 data 文件夹。")

    df = pd.read_csv(SCORES_FILE)
    for c in ["created_at_utc", "headline"]:
        if c not in df.columns:
            raise ValueError(f"缺少字段 {c}，请确认输入的是 nvda_finbert_probabilities.csv")
    df["created_at_utc"] = pd.to_datetime(df["created_at_utc"], utc=True, errors="coerce")
    df = df.dropna(subset=["created_at_utc"]).copy()
    for c in ["headline", "summary", "news_text", "source", "url"]:
        if c not in df.columns:
            df[c] = ""
        df[c] = df[c].fillna("").astype(str)
    df["search_text"] = (df["headline"] + " " + df["summary"]).str.strip()
    df["normalized_headline"] = df["headline"].map(norm_text)
    df["normalized_text"] = df["search_text"].map(norm_text)

    direct_re = re.compile("|".join(DIRECT_TERMS), flags=re.I)
    indirect_re = re.compile("|".join(INDIRECT_TERMS), flags=re.I)
    df["relevance_class"] = np.where(
        df["search_text"].str.contains(direct_re, na=False), "direct",
        np.where(df["search_text"].str.contains(indirect_re, na=False), "indirect", "review")
    )
    df["relevance_rule_note"] = np.select(
        [df["relevance_class"].eq("direct"), df["relevance_class"].eq("indirect")],
        ["direct keyword match; still sample-review",
         "industry keyword match; consider separate sensitivity test"],
        default="no keyword match; manual review recommended"
    )

    df["url_key"] = df["url"].str.split("?", n=1).str[0].str.rstrip("/").str.lower()
    valid_url = df["url_key"].ne("")
    df["duplicate_by_url"] = False
    df.loc[valid_url, "duplicate_by_url"] = df.loc[valid_url].duplicated("url_key", keep="first")
    df["duplicate_by_text"] = df["normalized_text"].ne("") & df.duplicated("normalized_text", keep="first")
    df["duplicate_by_headline"] = df["normalized_headline"].ne("") & df.duplicated("normalized_headline", keep="first")
    # Flag exact URL/text duplicates for default attention counts; headline-only repeats are retained for review.
    df["duplicate_flag"] = df["duplicate_by_url"] | df["duplicate_by_text"]
    df["unique_for_attention"] = ~df["duplicate_flag"]

    score_cols = ["positive_prob", "neutral_prob", "negative_prob"]
    for c in score_cols:
        if c not in df.columns:
            raise ValueError(f"FinBERT 文件缺少 {c}")
        df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.sort_values("created_at_utc").reset_index(drop=True)
    audit_path = OUT / "nvda_news_relevance_dedup_audit.csv"
    df.to_csv(audit_path, index=False, encoding="utf-8-sig")

    summary = df["relevance_class"].value_counts(dropna=False).rename_axis("relevance_class").reset_index(name="rows")
    summary.to_csv(OUT / "nvda_news_relevance_summary.csv", index=False, encoding="utf-8-sig")

    stock = pd.read_csv(STOCK_FILE)
    stock["timestamp_utc"] = pd.to_datetime(stock["timestamp_utc"], utc=True, errors="coerce")
    stock = stock.dropna(subset=["timestamp_utc"]).sort_values("timestamp_utc").copy()

    use = df.loc[df["unique_for_attention"] & df["relevance_class"].eq("direct")].copy()
    use = use.sort_values("created_at_utc")
    feature_rows = []
    for t in stock["timestamp_utc"]:
        row = {"timestamp_utc": t}
        for mins in [15, 30, 60]:
            w = use[(use["created_at_utc"] > t - pd.Timedelta(minutes=mins)) &
                    (use["created_at_utc"] <= t)]
            row[f"news_count_{mins}m"] = int(len(w))
            row[f"source_count_{mins}m"] = int(w.loc[w["source"].str.strip().ne(""), "source"].nunique())
            for c in score_cols:
                row[f"{c}_{mins}m"] = float(w[c].mean()) if len(w) and w[c].notna().any() else np.nan
            row[f"negative_prob_std_{mins}m"] = (
                float(w["negative_prob"].std(ddof=0)) if len(w) > 1
                else (0.0 if len(w) == 1 else np.nan)
            )
        raw60 = df[(df["created_at_utc"] > t - pd.Timedelta(minutes=60)) &
                   (df["created_at_utc"] <= t) & df["relevance_class"].eq("direct")]
        row["duplicate_ratio_60m"] = float(raw60["duplicate_flag"].sum() / len(raw60)) if len(raw60) else 0.0
        row["has_news_60m"] = int(row["news_count_60m"] > 0)
        feature_rows.append(row)

    features = pd.DataFrame(feature_rows)
    # Baseline uses prior bars only, excluding the current count.
    x = features["news_count_60m"].astype(float)
    mu = x.shift(1).rolling(96, min_periods=20).mean()
    sd = x.shift(1).rolling(96, min_periods=20).std(ddof=0)
    features["attention_surprise"] = ((x - mu) / sd.replace(0, np.nan)).replace([np.inf, -np.inf], np.nan)
    features.to_csv(OUT / "nvda_news_attention_sentiment_features.csv", index=False, encoding="utf-8-sig")

    print("完成，生成文件：")
    print(audit_path)
    print(OUT / "nvda_news_relevance_summary.csv")
    print(OUT / "nvda_news_attention_sentiment_features.csv")
    print("\n相关性分类统计（关键词自动初筛，不是最终人工标签）：")
    print(summary.to_string(index=False))
    print("\n注意：先抽查 relevance_class 分类；本脚本不会仅因标题重复就删除新闻。")
    print("建模前还需验证新闻与 K 线时间定义，确保特征只使用预测时点已发布的新闻。")

if __name__ == "__main__":
    main()
