from pathlib import Path
import pandas as pd
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from torch.nn.functional import softmax
from tqdm import tqdm

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)

NEWS_FILE = DATA / "nvda_news_clean.csv"
OUTPUT_FILE = OUT / "nvda_finbert_probabilities.csv"
MODEL_NAME = "ProsusAI/finbert"
BATCH_SIZE = 16
MAX_LENGTH = 256

def main():
    if not NEWS_FILE.exists():
        raise FileNotFoundError(f"找不到新闻文件：{NEWS_FILE}")

    df = pd.read_csv(NEWS_FILE)
    if "news_text" not in df.columns:
        raise ValueError("新闻文件缺少 news_text 列，请确认使用 nvda_news_clean.csv")

    texts = df["news_text"].fillna("").astype(str).tolist()
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForSequenceClassification.from_pretrained(MODEL_NAME)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.eval()
    print(f"运行设备：{device}；新闻条数：{len(df)}")

    all_probs = []
    labels = ["positive", "negative", "neutral"]
    for start in tqdm(range(0, len(texts), BATCH_SIZE), desc="FinBERT"):
        batch = texts[start:start + BATCH_SIZE]
        encoded = tokenizer(
            batch, padding=True, truncation=True, max_length=MAX_LENGTH,
            return_tensors="pt"
        )
        encoded = {k: v.to(device) for k, v in encoded.items()}
        with torch.no_grad():
            logits = model(**encoded).logits
            probs = softmax(logits, dim=1).cpu().numpy()
        all_probs.append(probs)

    probs = np.vstack(all_probs)
    # ProsusAI/finbert label order is typically positive, negative, neutral;
    # read config mapping instead of assuming a different label order.
    id2label = {int(k): str(v).lower() for k, v in model.config.id2label.items()}
    out = df.copy()
    for idx in range(probs.shape[1]):
        label = id2label.get(idx, labels[idx]).lower()
        if label in {"positive", "negative", "neutral"}:
            out[f"{label}_prob"] = probs[:, idx]
    prob_cols = ["positive_prob", "neutral_prob", "negative_prob"]
    for c in prob_cols:
        if c not in out.columns:
            raise ValueError(f"FinBERT 输出缺少 {c}，实际标签映射为：{id2label}")
    out["finbert_sentiment"] = out[prob_cols].idxmax(axis=1).str.replace("_prob", "", regex=False)
    out.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")
    print(f"完成：{OUTPUT_FILE}")
    print(out[prob_cols + ["finbert_sentiment"]].head())

if __name__ == "__main__":
    main()
