from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "output"
OUT.mkdir(parents=True, exist_ok=True)

# Accept the recommended project layout (data/ and output/) and the flat layout
# used when the source files are stored beside this script.
def resolve_file(filename: str, preferred: Path) -> Path:
    candidates = [preferred, ROOT / filename, OUT / filename, DATA / filename]
    for path in candidates:
        if path.exists():
            return path
    checked = "\n".join(str(p) for p in candidates)
    raise FileNotFoundError(f"找不到 {filename}。已检查：\n{checked}")

STOCK_FILE = resolve_file("nvda_stock_15min_clean.csv", DATA / "nvda_stock_15min_clean.csv")
AUDIT_FILE = resolve_file("nvda_news_relevance_dedup_audit.csv", OUT / "nvda_news_relevance_dedup_audit.csv")
OUTPUT_FILE = OUT / "nvda_model_dataset.csv"
REPORT_FILE = OUT / "nvda_model_dataset_quality_report.txt"
FEATURE_REPORT_FILE = OUT / "nvda_model_dataset_feature_quality.csv"
BAR = pd.Timedelta(minutes=15)
SCORE_COLS = ["positive_prob", "neutral_prob", "negative_prob"]


def parse_bool(series: pd.Series) -> pd.Series:
    """Robustly parse CSV booleans (True/False, 1/0, strings)."""
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False)
    values = series.astype(str).str.strip().str.lower()
    return values.isin({"true", "1", "yes", "y", "t"})


def get_window_bounds(times_ns: np.ndarray, start_ns: int, end_ns: int):
    """Window is [start, end): includes left boundary, excludes prediction instant."""
    left = np.searchsorted(times_ns, start_ns, side="left")
    right = np.searchsorted(times_ns, end_ns, side="left")
    return left, right


def main():
    print("读取股票文件：", STOCK_FILE)
    print("读取新闻审核文件：", AUDIT_FILE)
    stock = pd.read_csv(STOCK_FILE)
    news = pd.read_csv(AUDIT_FILE)

    # ----- Validate and parse timestamps -----
    if "timestamp_utc" not in stock.columns:
        raise ValueError("股票文件缺少 timestamp_utc 字段。")
    if "close" not in stock.columns:
        raise ValueError("股票文件缺少 close 字段。")
    if "created_at_utc" not in news.columns:
        raise ValueError("新闻审核文件缺少 created_at_utc 字段。")
    for col in ["relevance_class", "duplicate_flag", "unique_for_attention", *SCORE_COLS]:
        if col not in news.columns:
            raise ValueError(f"新闻审核文件缺少字段：{col}")

    stock["timestamp_utc"] = pd.to_datetime(stock["timestamp_utc"], utc=True, errors="coerce")
    news["created_at_utc"] = pd.to_datetime(news["created_at_utc"], utc=True, errors="coerce")
    stock["close"] = pd.to_numeric(stock["close"], errors="coerce")
    stock = stock.dropna(subset=["timestamp_utc", "close"]).copy()
    stock = stock.sort_values("timestamp_utc").drop_duplicates("timestamp_utc", keep="last").reset_index(drop=True)
    news = news.dropna(subset=["created_at_utc"]).copy()
    news = news.sort_values("created_at_utc").reset_index(drop=True)

    # Timestamp evidence: existing data has timestamp_utc == bar_time_utc,
    # and e.g. 2022-01-03 14:30 UTC == 09:30 New York time, the US regular-session open.
    # This is treated as BAR START TIME. The script also reports this assumption explicitly.
    timestamp_is_bar_start = True
    stock["prediction_time_utc"] = stock["timestamp_utc"] + BAR

    # ----- Build target: next continuous 15-minute bar close vs current close -----
    next_timestamp = stock["timestamp_utc"].shift(-1)
    next_close = stock["close"].shift(-1)
    consecutive = next_timestamp.eq(stock["timestamp_utc"] + BAR)
    valid_current_close = stock["close"].notna() & stock["close"].ne(0)
    valid_next_close = next_close.notna()
    target_valid = consecutive & valid_current_close & valid_next_close
    future_return = (next_close / stock["close"] - 1).where(target_valid)
    stock["future_return_15m"] = future_return
    stock["target_up"] = np.nan
    stock.loc[target_valid, "target_up"] = (future_return.loc[target_valid] > 0).astype(int)

    # ----- Prepare audited news -----
    news["relevance_class"] = news["relevance_class"].fillna("").astype(str).str.strip().str.lower()
    news["duplicate_flag_bool"] = parse_bool(news["duplicate_flag"])
    news["unique_flag_bool"] = parse_bool(news["unique_for_attention"])
    for col in SCORE_COLS:
        news[col] = pd.to_numeric(news[col], errors="coerce")
        # Probabilities outside [0, 1] are invalid, so convert them to missing.
        news.loc[~news[col].between(0, 1), col] = np.nan
    if "source" not in news.columns:
        news["source"] = ""
    news["source"] = news["source"].fillna("").astype(str).str.strip()

    # Use direct-relevance stories only, following the existing audit's keyword classification.
    # Attention/sentiment count excludes exact URL/text duplicates; duplicate headlines alone are retained.
    direct_all = news[news["relevance_class"].eq("direct")].copy().sort_values("created_at_utc")
    direct_unique = direct_all[direct_all["unique_flag_bool"] & ~direct_all["duplicate_flag_bool"]].copy()
    # If boolean columns conflict, duplicate_flag takes precedence and is excluded.
    direct_unique = direct_unique.sort_values("created_at_utc").reset_index(drop=True)

    print(f"诊断：新闻审核文件共 {len(news):,} 行")
    print(f"诊断：direct 新闻 {len(direct_all):,} 条")
    print(f"诊断：去重后 direct 新闻 {len(direct_unique):,} 条")
    if len(direct_unique):
        print("诊断：去重后新闻时间范围：",
              direct_unique["created_at_utc"].min(), "至",
              direct_unique["created_at_utc"].max())
    direct_all = direct_all.sort_values("created_at_utc").reset_index(drop=True)
    unique_ns = direct_unique["created_at_utc"].astype("int64").to_numpy()
    all_direct_ns = direct_all["created_at_utc"].astype("int64").to_numpy()

    # ----- Feature rows aligned to prediction time -----
    # Use NumPy arrays and prefix sums so the script stays fast on ~28k stock bars.
    unique_times = direct_unique["created_at_utc"].astype("int64").to_numpy()
    unique_sources = direct_unique["source"].to_numpy(dtype=str)
    score_arrays = {c: direct_unique[c].to_numpy(dtype=float) for c in SCORE_COLS}

    def prefix_for(values):
        valid = np.isfinite(values)
        sums = np.concatenate(([0.0], np.cumsum(np.where(valid, values, 0.0))))
        counts = np.concatenate(([0], np.cumsum(valid.astype(np.int64))))
        squares = np.concatenate(([0.0], np.cumsum(np.where(valid, values * values, 0.0))))
        return sums, counts, squares

    score_prefix = {c: prefix_for(arr) for c, arr in score_arrays.items()}
    all_direct_times = direct_all["created_at_utc"].astype("int64").to_numpy()
    duplicate_values = direct_all["duplicate_flag_bool"].to_numpy(dtype=np.int64)
    duplicate_prefix = np.concatenate(([0], np.cumsum(duplicate_values)))

    rows = []
    for pred_time in stock["prediction_time_utc"]:
        end_ns = pred_time.value  # strict cutoff: timestamp exactly at prediction time is excluded
        row = {}
        for mins in (15, 30, 60):
            start_ns = (pred_time - pd.Timedelta(minutes=mins)).value
            left, right = get_window_bounds(unique_times, start_ns, end_ns)
            row[f"news_count_{mins}m"] = int(right - left)
            nonempty_sources = unique_sources[left:right]
            row[f"source_count_{mins}m"] = int(len(set(x for x in nonempty_sources if x)))

            for col in SCORE_COLS:
                sums, counts, _ = score_prefix[col]
                n_valid = int(counts[right] - counts[left])
                row[f"{col}_{mins}m"] = (
                    float((sums[right] - sums[left]) / n_valid) if n_valid else np.nan
                )

            neg_sums, neg_counts, neg_squares = score_prefix["negative_prob"]
            n_neg = int(neg_counts[right] - neg_counts[left])
            if n_neg:
                neg_mean = (neg_sums[right] - neg_sums[left]) / n_neg
                neg_var = max(0.0, (neg_squares[right] - neg_squares[left]) / n_neg - neg_mean**2)
                row[f"negative_prob_std_{mins}m"] = float(np.sqrt(neg_var)) if n_neg > 1 else 0.0
            else:
                row[f"negative_prob_std_{mins}m"] = np.nan

        raw_left, raw_right = get_window_bounds(
            all_direct_times,
            (pred_time - pd.Timedelta(minutes=60)).value,
            end_ns,
        )
        raw_count = raw_right - raw_left
        duplicate_count = int(duplicate_prefix[raw_right] - duplicate_prefix[raw_left])
        row["duplicate_ratio_60m"] = float(duplicate_count / raw_count) if raw_count else 0.0
        row["has_news_60m"] = int(row["news_count_60m"] > 0)
        row["log_news_count_60m"] = float(np.log1p(row["news_count_60m"]))
        rows.append(row)

    features = pd.DataFrame(rows)
    result = pd.concat([stock.reset_index(drop=True), features.reset_index(drop=True)], axis=1)

    # ----- Attention surprise: rolling baseline on prior observed stock bars only -----
    # 96 means 96 observed 15m bars, not 96 wall-clock minutes. A minimum std avoids
    # enormous z-scores caused by near-zero variability. Raw z-score is retained for audit.
    counts = result["news_count_60m"].astype(float)
    hist_mean = counts.shift(1).rolling(window=96, min_periods=20).mean()
    hist_std = counts.shift(1).rolling(window=96, min_periods=20).std(ddof=0)
    min_std = 0.25
    raw_surprise = ((counts - hist_mean) / hist_std.where(hist_std >= min_std)).replace([np.inf, -np.inf], np.nan)
    result["attention_surprise_raw"] = raw_surprise
    result["attention_surprise"] = raw_surprise.clip(-5, 5)

    # Add a clear target validity indicator before filtering for auditability in report.
    result["target_valid"] = result["target_up"].notna()
    result["target_up"] = result["target_up"].astype("Int64")

    # Keep only rows with a valid target: next bar must be exactly 15 minutes later.
    model = result[result["target_valid"]].copy().reset_index(drop=True)
    model["target_up"] = model["target_up"].astype(int)
    model.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")

    # ----- Quality report -----
    feature_cols = [c for c in model.columns if c.startswith(("news_count_", "source_count_", "positive_prob_", "neutral_prob_", "negative_prob_", "negative_prob_std_"))]
    feature_cols += ["duplicate_ratio_60m", "has_news_60m", "log_news_count_60m", "attention_surprise_raw", "attention_surprise"]
    feature_rows = []
    for col in dict.fromkeys(feature_cols):
        s = model[col]
        feature_rows.append({
            "feature": col,
            "non_missing": int(s.notna().sum()),
            "missing": int(s.isna().sum()),
            "zero_count": int((s == 0).sum()) if pd.api.types.is_numeric_dtype(s) else np.nan,
            "min": float(s.min()) if s.notna().any() else np.nan,
            "median": float(s.median()) if s.notna().any() else np.nan,
            "mean": float(s.mean()) if s.notna().any() else np.nan,
            "max": float(s.max()) if s.notna().any() else np.nan,
        })
    pd.DataFrame(feature_rows).to_csv(FEATURE_REPORT_FILE, index=False, encoding="utf-8-sig")

    stock_gaps = stock["timestamp_utc"].diff().dropna().dt.total_seconds().div(60)
    nonzero_counts = int((model["news_count_60m"] > 0).sum())
    if len(direct_unique) > 0 and nonzero_counts == 0:
        raise RuntimeError(
            "发现 direct 新闻但所有 60 分钟窗口均未匹配到新闻。"
            "请检查股票/新闻时间戳、时区，以及脚本实际读取的文件路径。"
        )
    target_counts = model["target_up"].value_counts().to_dict()
    report = [
        "NVDA 15-minute model dataset quality report",
        "===========================================",
        f"Stock input: {STOCK_FILE}",
        f"News audit input: {AUDIT_FILE}",
        f"Output dataset: {OUTPUT_FILE}",
        "",
        "Timestamp interpretation:",
        "- timestamp_utc is treated as the START time of each 15-minute bar.",
        "- Evidence in source: timestamp_utc equals bar_time_utc; 2022-01-03 14:30 UTC corresponds to 09:30 New York time.",
        "- prediction_time_utc = timestamp_utc + 15 minutes (bar end).",
        "- News window is [prediction_time - window, prediction_time): news at the exact prediction timestamp is excluded.",
        "- Target compares current bar close with the next bar close, only when next bar starts exactly 15 minutes later.",
        "",
        "Row counts:",
        f"- Stock rows after timestamp cleanup/deduplication: {len(stock)}",
        f"- News audit rows with valid timestamps: {len(news)}",
        f"- Direct-relevance news rows: {len(direct_all)}",
        f"- Direct-relevance news rows kept after URL/text dedup flags: {len(direct_unique)}",
        f"- Rows with valid next-contiguous-bar target: {int(target_valid.sum())}",
        f"- Output model rows: {len(model)}",
        "",
        "Target distribution:",
        f"- target_up=1: {target_counts.get(1, 0)}",
        f"- target_up=0: {target_counts.get(0, 0)}",
        f"- Up share: {model['target_up'].mean():.6f}" if len(model) else "- Up share: N/A",
        "",
        "News feature checks:",
        f"- Output rows with at least one direct unique news item in prior 60 minutes: {nonzero_counts}",
        f"- Share with news_count_60m > 0: {nonzero_counts / len(model):.6f}" if len(model) else "- Share with news_count_60m > 0: N/A",
        f"- Rows with non-missing positive_prob_60m: {int(model['positive_prob_60m'].notna().sum())}",
        f"- Rows with non-missing negative_prob_60m: {int(model['negative_prob_60m'].notna().sum())}",
        f"- Rows with non-missing attention_surprise: {int(model['attention_surprise'].notna().sum())}",
        "- News sentiment remains NaN when no eligible news with a valid score exists; it is not replaced by neutral sentiment.",
        "- attention_surprise uses prior 96 observed bars, at least 20 observations, and only calculates when historical std >= 0.25; displayed value is clipped to [-5, 5].",
        "",
        "Stock timestamp gap checks:",
        f"- Median observed gap in minutes: {stock_gaps.median() if len(stock_gaps) else np.nan}",
        f"- Gaps exactly 15 minutes: {int((stock_gaps == 15).sum())}",
        f"- Gaps not equal to 15 minutes: {int((stock_gaps != 15).sum())}",
        "",
        "Cautions:",
        "- Relevance class 'direct' is keyword-based and can contain false positives; manually review a sample.",
        "- The source field is sparse; source_count may understate the true number of publishers.",
        "- This script creates the dataset only. It does not train or evaluate models.",
    ]
    REPORT_FILE.write_text("\n".join(report) + "\n", encoding="utf-8")

    print("\n完成。未训练模型。生成文件：")
    print("1.", OUTPUT_FILE)
    print("2.", REPORT_FILE)
    print("3.", FEATURE_REPORT_FILE)
    print("\n关键质量检查：")
    print(f"有效建模行数：{len(model):,}")
    print(f"news_count_60m > 0：{nonzero_counts:,} 行（{nonzero_counts / len(model):.2%}）" if len(model) else "没有有效建模行")
    print(f"positive_prob_60m 非缺失：{model['positive_prob_60m'].notna().sum():,} 行")
    print(f"attention_surprise 非缺失：{model['attention_surprise'].notna().sum():,} 行")
    print("target_up 分布：", model["target_up"].value_counts().sort_index().to_dict())
    print("请打开质量报告检查后再进入建模。")


if __name__ == "__main__":
    main()
