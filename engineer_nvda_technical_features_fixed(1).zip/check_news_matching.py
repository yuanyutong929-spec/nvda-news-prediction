
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent

stock_file = ROOT / "data" / "nvda_stock_15min_clean.csv"
news_file = ROOT / "output" / "nvda_news_relevance_dedup_audit.csv"

print("开始检查新闻匹配问题...", flush=True)

stock = pd.read_csv(stock_file)
news = pd.read_csv(news_file)

stock["timestamp_utc"] = pd.to_datetime(
    stock["timestamp_utc"], utc=True, errors="coerce"
)
news["created_at_utc"] = pd.to_datetime(
    news["created_at_utc"], utc=True, errors="coerce"
)

print("股票数据行数：", len(stock), flush=True)
print("新闻数据行数：", len(news), flush=True)

direct = news[
    news["relevance_class"].astype(str).str.strip().str.lower()
    == "direct"
].copy()
print("Direct 新闻时间范围：", direct["created_at_utc"].min(), "到", direct["created_at_utc"].max())
print("新闻列名：", news.columns.tolist())

print("Direct 新闻数量：", len(direct), flush=True)

# 预测时点 = 当前15分钟K线的结束时间
prediction_times = (
    stock["timestamp_utc"] + pd.Timedelta(minutes=15)
)

news_times = direct["created_at_utc"].dropna().sort_values()

counts = []

for t in prediction_times.dropna():
    window_start = t - pd.Timedelta(minutes=60)

    count = (
        (news_times >= window_start)
        & (news_times < t)
    ).sum()

    counts.append(count)

print(
    "至少匹配到一条新闻的预测时点：",
    sum(c > 0 for c in counts),
    flush=True
)

print(
    "过去60分钟新闻数量最大值：",
    max(counts) if counts else 0,
    flush=True
)

print("诊断完成。", flush=True)
