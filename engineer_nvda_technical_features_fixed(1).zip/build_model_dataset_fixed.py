from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "output"
OUT.mkdir(parents=True, exist_ok=True)

def resolve_file(filename: str, preferred: Path) -> Path:
    candidates = [preferred, ROOT / filename, OUT / filename, DATA / filename]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        f"找不到 {filename}。已检查：\n" + "\n".join(str(p) for p in candidates)
    )

STOCK_FILE = resolve_file(
    "nvda_stock_15min_clean.csv", DATA / "nvda_stock_15min_clean.csv"
)
AUDIT_FILE = resolve_file(
    "nvda_news_relevance_dedup_audit.csv",
    OUT / "nvda_news_relevance_dedup_audit.csv",
)
OUTPUT_FILE = OUT / "nvda_model_dataset.csv"
REPORT_FILE = OUT / "nvda_model_dataset_quality_report.txt"
FEATURE_REPORT_FILE = OUT / "nvda_model_dataset_feature_quality.csv"

BAR = pd.Timedelta(minutes=15)
SCORE_COLS = ["positive_prob", "neutral_prob", "negative_prob"]


def parse_bool(series: pd.Series) -> pd.Series:
    """将 CSV 中的 True/False、1/0、yes/no 等安全转换为布尔值。"""
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False)
    values = series.astype(str).str.strip().str.lower()
    return values.isin({"true", "1", "yes", "y", "t"})


def get_window_bounds(times_ns: np.ndarray, start_ns: int, end_ns: int):
    """返回 [start, end) 时间窗口的左右边界。times_ns 必须升序排列。"""
    left = np.searchsorted(times_ns, start_ns, side="left")
    right = np.searchsorted(times_ns, end_ns, side="left")
    return int(left), int(right)


def prefix_for(values: np.ndarray):
    valid = np.isfinite(values)
    sums = np.concatenate(([0.0], np.cumsum(np.where(valid, values, 0.0))))
    counts = np.concatenate(([0], np.cumsum(valid.astype(np.int64))))
    squares = np.concatenate(([0.0], np.cumsum(np.where(valid, values * values, 0.0))))
    return sums, counts, squares


def main():
    print("读取股票文件：", STOCK_FILE)
    print("读取新闻审核文件：", AUDIT_FILE)

    stock = pd.read_csv(STOCK_FILE)
    news = pd.read_csv(AUDIT_FILE)

    for col in ["timestamp_utc", "close"]:
        if col not in stock.columns:
            raise ValueError(f"股票文件缺少字段：{col}")
    for col in ["created_at_utc", "relevance_class", "duplicate_flag",
                "unique_for_attention", *SCORE_COLS]:
        if col not in news.columns:
            raise ValueError(f"新闻审核文件缺少字段：{col}")

    # 统一解析为 UTC，并清理无效数据。
    stock["timestamp_utc"] = pd.to_datetime(
        stock["timestamp_utc"], utc=True, errors="coerce"
    )
    news["created_at_utc"] = pd.to_datetime(
        news["created_at_utc"], utc=True, errors="coerce"
    )
    stock["close"] = pd.to_numeric(stock["close"], errors="coerce")
    stock = stock.dropna(subset=["timestamp_utc", "close"]).copy()
    stock = (
        stock.sort_values("timestamp_utc")
        .drop_duplicates("timestamp_utc", keep="last")
        .reset_index(drop=True)
    )
    news = news.dropna(subset=["created_at_utc"]).copy()
    news["relevance_class"] = (
        news["relevance_class"].fillna("").astype(str).str.strip().str.lower()
    )
    news["duplicate_flag_bool"] = parse_bool(news["duplicate_flag"])
    news["unique_flag_bool"] = parse_bool(news["unique_for_attention"])

    for col in SCORE_COLS:
        news[col] = pd.to_numeric(news[col], errors="coerce")
        news.loc[~news[col].between(0, 1), col] = np.nan

    if "source" not in news.columns:
        news["source"] = ""
    news["source"] = news["source"].fillna("").astype(str).str.strip()
    news = news.sort_values("created_at_utc").reset_index(drop=True)

    # 股票时间戳视为 15 分钟 K 线开始时间；预测时点为 K 线结束时间。
    stock["prediction_time_utc"] = stock["timestamp_utc"] + BAR

    # 标签：当前 K 线收盘价到下一根连续 15 分钟 K 线收盘价的方向。
    next_timestamp = stock["timestamp_utc"].shift(-1)
    next_close = stock["close"].shift(-1)
    consecutive = next_timestamp.eq(stock["timestamp_utc"] + BAR)
    target_valid = consecutive & stock["close"].ne(0) & next_close.notna()
    future_return = (next_close / stock["close"] - 1).where(target_valid)
    stock["future_return_15m"] = future_return
    stock["target_up"] = np.nan
    stock.loc[target_valid, "target_up"] = (
        future_return.loc[target_valid] > 0
    ).astype(int)

    # 新闻分层：只使用 direct；attention/sentiment 排除标记为重复的新闻。
    direct_all = (
        news[news["relevance_class"].eq("direct")]
        .sort_values("created_at_utc")
        .reset_index(drop=True)
    )
    direct_unique = (
        direct_all[
            direct_all["unique_flag_bool"] & ~direct_all["duplicate_flag_bool"]
        ]
        .sort_values("created_at_utc")
        .reset_index(drop=True)
    )

    print("\n===== 新闻筛选诊断 =====")
    print("股票数据行数：", len(stock))
    print("审核新闻行数：", len(news))
    print("Direct 新闻总数：", len(direct_all))
    print("去重后 Direct 新闻数：", len(direct_unique))
    print("去重后新闻时间范围：",
          direct_unique["created_at_utc"].min() if len(direct_unique) else None,
          "到",
          direct_unique["created_at_utc"].max() if len(direct_unique) else None)

    if direct_unique.empty:
        raise RuntimeError("去重后的 Direct 新闻为 0 条，请检查审核表布尔字段。")

    # int64 纳秒时间戳；明确保证升序且同一单位。
    # 统一转换成纳秒时间戳，与 pred_time.value 保持一致
    unique_times = direct_unique["created_at_utc"].map(
        lambda t: t.value
    ).to_numpy(dtype=np.int64)

    all_direct_times = direct_all["created_at_utc"].map(
        lambda t: t.value
    ).to_numpy(dtype=np.int64)
    if not np.all(np.diff(unique_times) >= 0):
        raise RuntimeError("unique_times 未按时间升序排列。")
    if not np.all(np.diff(all_direct_times) >= 0):
        raise RuntimeError("all_direct_times 未按时间升序排列。")

    unique_sources = direct_unique["source"].to_numpy(dtype=str)
    score_arrays = {
        col: direct_unique[col].to_numpy(dtype=float) for col in SCORE_COLS
    }
    score_prefix = {col: prefix_for(values) for col, values in score_arrays.items()}

    duplicate_values = direct_all["duplicate_flag_bool"].to_numpy(dtype=np.int64)
    duplicate_prefix = np.concatenate(([0], np.cumsum(duplicate_values)))

    rows = []
    debug_unique_matches = 0
    debug_direct_matches = 0

    for pred_time in stock["prediction_time_utc"]:
        end_ns = int(pred_time.value)
        start_60_ns = int((pred_time - pd.Timedelta(minutes=60)).value)

        # 在正式特征循环中验证匹配，防止独立诊断与生产代码不一致。
        l60, r60 = get_window_bounds(unique_times, start_60_ns, end_ns)
        ld60, rd60 = get_window_bounds(all_direct_times, start_60_ns, end_ns)
        if r60 > l60:
            debug_unique_matches += 1
        if rd60 > ld60:
            debug_direct_matches += 1

        row = {}
        for mins in (15, 30, 60):
            start_ns = int((pred_time - pd.Timedelta(minutes=mins)).value)
            left, right = get_window_bounds(unique_times, start_ns, end_ns)
            row[f"news_count_{mins}m"] = right - left
            nonempty_sources = unique_sources[left:right]
            row[f"source_count_{mins}m"] = len(
                set(x for x in nonempty_sources if x)
            )

            for col in SCORE_COLS:
                sums, counts, _ = score_prefix[col]
                n_valid = int(counts[right] - counts[left])
                row[f"{col}_{mins}m"] = (
                    float((sums[right] - sums[left]) / n_valid)
                    if n_valid else np.nan
                )

            neg_sums, neg_counts, neg_squares = score_prefix["negative_prob"]
            n_neg = int(neg_counts[right] - neg_counts[left])
            if n_neg:
                neg_mean = (neg_sums[right] - neg_sums[left]) / n_neg
                neg_var = max(
                    0.0,
                    (neg_squares[right] - neg_squares[left]) / n_neg - neg_mean**2,
                )
                row[f"negative_prob_std_{mins}m"] = (
                    float(np.sqrt(neg_var)) if n_neg > 1 else 0.0
                )
            else:
                row[f"negative_prob_std_{mins}m"] = np.nan

        raw_left, raw_right = get_window_bounds(
            all_direct_times, start_60_ns, end_ns
        )
        raw_count = raw_right - raw_left
        duplicate_count = int(
            duplicate_prefix[raw_right] - duplicate_prefix[raw_left]
        )
        row["duplicate_ratio_60m"] = (
            float(duplicate_count / raw_count) if raw_count else 0.0
        )
        row["has_news_60m"] = int(row["news_count_60m"] > 0)
        row["log_news_count_60m"] = float(np.log1p(row["news_count_60m"]))
        rows.append(row)

    print("\n===== 正式循环匹配结果 =====")
    print("去重新闻匹配时点数：", debug_unique_matches)
    print("全部 Direct 新闻匹配时点数：", debug_direct_matches)
    print("去重新闻时间数组长度：", len(unique_times))
    print("全部 Direct 新闻时间数组长度：", len(all_direct_times))

    # 若匹配结果仍全为 0，停止生成错误数据集，并给出更直接的时间证据。
    if debug_direct_matches == 0:
        print("股票预测时间范围：",
              stock["prediction_time_utc"].min(), "到",
              stock["prediction_time_utc"].max())
        print("Direct 新闻时间范围：",
              direct_all["created_at_utc"].min(), "到",
              direct_all["created_at_utc"].max())
        raise RuntimeError(
            "正式脚本内全部 Direct 新闻均未匹配。请将以上诊断输出发来；"
            "脚本已停止，避免把全零新闻特征写入数据集。"
        )

    features = pd.DataFrame(rows)
    result = pd.concat(
        [stock.reset_index(drop=True), features.reset_index(drop=True)], axis=1
    )

    # 关注度异常：与此前 96 根已观测 K 线比较，不使用未来数据。
    counts = result["news_count_60m"].astype(float)
    hist_mean = counts.shift(1).rolling(window=96, min_periods=20).mean()
    hist_std = counts.shift(1).rolling(window=96, min_periods=20).std(ddof=0)
    min_std = 0.25
    raw_surprise = (
        (counts - hist_mean) / hist_std.where(hist_std >= min_std)
    ).replace([np.inf, -np.inf], np.nan)
    result["attention_surprise_raw"] = raw_surprise
    result["attention_surprise"] = raw_surprise.clip(-5, 5)

    result["target_valid"] = result["target_up"].notna()
    result["target_up"] = result["target_up"].astype("Int64")
    model = result[result["target_valid"]].copy().reset_index(drop=True)
    model["target_up"] = model["target_up"].astype(int)

    nonzero_counts = int((model["news_count_60m"] > 0).sum())
    if nonzero_counts == 0:
        raise RuntimeError(
            "正式循环已匹配到新闻，但最终有效建模行的 news_count_60m 全为 0。"
            "请检查特征表与股票表的行对齐。"
        )

    model.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")

    feature_cols = [
        col for col in model.columns
        if col.startswith((
            "news_count_", "source_count_", "positive_prob_", "neutral_prob_",
            "negative_prob_", "negative_prob_std_"
        ))
    ]
    feature_cols += [
        "duplicate_ratio_60m", "has_news_60m", "log_news_count_60m",
        "attention_surprise_raw", "attention_surprise"
    ]
    feature_rows = []
    for col in dict.fromkeys(feature_cols):
        s = model[col]
        feature_rows.append({
            "feature": col,
            "non_missing": int(s.notna().sum()),
            "missing": int(s.isna().sum()),
            "zero_count": int((s == 0).sum())
                if pd.api.types.is_numeric_dtype(s) else np.nan,
            "min": float(s.min()) if s.notna().any() else np.nan,
            "median": float(s.median()) if s.notna().any() else np.nan,
            "mean": float(s.mean()) if s.notna().any() else np.nan,
            "max": float(s.max()) if s.notna().any() else np.nan,
        })
    pd.DataFrame(feature_rows).to_csv(
        FEATURE_REPORT_FILE, index=False, encoding="utf-8-sig"
    )

    stock_gaps = (
        stock["timestamp_utc"].diff().dropna().dt.total_seconds().div(60)
    )
    target_counts = model["target_up"].value_counts().to_dict()
    report = [
        "NVDA 15-minute model dataset quality report",
        "===========================================",
        f"Stock input: {STOCK_FILE}",
        f"News audit input: {AUDIT_FILE}",
        f"Output dataset: {OUTPUT_FILE}",
        "",
        "Timestamp interpretation:",
        "- timestamp_utc is treated as the START time of each 15-minute bar.",
        "- prediction_time_utc = timestamp_utc + 15 minutes (bar end).",
        "- News window is [prediction_time - window, prediction_time).",
        "- News exactly at prediction time is excluded.",
        "- Target compares current bar close with the next bar close, only for consecutive 15-minute bars.",
        "",
        "Row counts:",
        f"- Stock rows after cleanup: {len(stock)}",
        f"- News audit rows with valid timestamps: {len(news)}",
        f"- Direct-relevance news rows: {len(direct_all)}",
        f"- Direct-relevance rows kept after dedup flags: {len(direct_unique)}",
        f"- Valid target rows: {int(target_valid.sum())}",
        f"- Output model rows: {len(model)}",
        "",
        "Target distribution:",
        f"- target_up=1: {target_counts.get(1, 0)}",
        f"- target_up=0: {target_counts.get(0, 0)}",
        f"- Up share: {model['target_up'].mean():.6f}" if len(model) else "- Up share: N/A",
        "",
        "News feature checks:",
        f"- Unique-news matching prediction times before target filter: {debug_unique_matches}",
        f"- All-direct matching prediction times before target filter: {debug_direct_matches}",
        f"- Output rows with news_count_60m > 0: {nonzero_counts}",
        f"- Share with news_count_60m > 0: {nonzero_counts / len(model):.6f}" if len(model) else "- Share with news_count_60m > 0: N/A",
        f"- Rows with non-missing positive_prob_60m: {int(model['positive_prob_60m'].notna().sum())}",
        f"- Rows with non-missing negative_prob_60m: {int(model['negative_prob_60m'].notna().sum())}",
        f"- Rows with non-missing attention_surprise: {int(model['attention_surprise'].notna().sum())}",
        "- Sentiment remains missing if no eligible news has a valid score.",
        "- attention_surprise uses prior 96 observed bars, min_periods=20, historical std >= 0.25, clipped to [-5, 5].",
        "",
        "Stock timestamp gap checks:",
        f"- Median observed gap in minutes: {stock_gaps.median() if len(stock_gaps) else np.nan}",
        f"- Gaps exactly 15 minutes: {int((stock_gaps == 15).sum())}",
        f"- Gaps not equal to 15 minutes: {int((stock_gaps != 15).sum())}",
        "",
        "Cautions:",
        "- Direct relevance is keyword-based and may contain false positives.",
        "- source_count may understate publisher count if source metadata is sparse.",
        "- This script creates the dataset only; it does not train models.",
    ]
    REPORT_FILE.write_text("\n".join(report) + "\n", encoding="utf-8")

    print("\n完成。未训练模型。生成文件：")
    print("1.", OUTPUT_FILE)
    print("2.", REPORT_FILE)
    print("3.", FEATURE_REPORT_FILE)
    print("\n关键质量检查：")
    print(f"有效建模行数：{len(model):,}")
    print(f"news_count_60m > 0：{nonzero_counts:,} 行（{nonzero_counts / len(model):.2%}）")
    print(f"positive_prob_60m 非缺失：{model['positive_prob_60m'].notna().sum():,} 行")
    print(f"attention_surprise 非缺失：{model['attention_surprise'].notna().sum():,} 行")
    print("target_up 分布：", model["target_up"].value_counts().sort_index().to_dict())
    print("请检查质量报告后再进入建模。")


if __name__ == "__main__":
    main()
