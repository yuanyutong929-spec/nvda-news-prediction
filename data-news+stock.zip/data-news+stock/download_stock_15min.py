
import requests
import pandas as pd
from getpass import getpass
from pathlib import Path
import time

API_KEY = getpass("请输入 Alpaca API Key: ")
API_SECRET = getpass("请输入 Alpaca Secret Key: ")

URL = "https://data.alpaca.markets/v2/stocks/NVDA/bars"
FOLDER = Path(__file__).resolve().parent
OUTPUT = FOLDER / "nvda_stock_15min_2022_2025.csv"

HEADERS = {
    "APCA-API-KEY-ID": API_KEY,
    "APCA-API-SECRET-KEY": API_SECRET,
}

all_bars = []

# 按月下载，覆盖 2022 年至 2025 年
for year in range(2022, 2026):
    for month in range(1, 13):
        start = pd.Timestamp(
            year=year, month=month, day=1, tz="UTC"
        )

        if month == 12:
            end = pd.Timestamp(
                year=year + 1, month=1, day=1, tz="UTC"
            )
        else:
            end = pd.Timestamp(
                year=year, month=month + 1, day=1, tz="UTC"
            )

        params = {
            "timeframe": "15Min",
            "start": start.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "end": end.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "limit": 10000,
            "adjustment": "split",
            "feed": "iex",
            "sort": "asc",
        }

        month_bars = []

        while True:
            response = requests.get(
                URL,
                headers=HEADERS,
                params=params,
                timeout=60,
            )

            if response.status_code == 429:
                print("请求太频繁，等待 15 秒后重试……")
                time.sleep(15)
                continue

            if not response.ok:
                print("下载失败：", year, month)
                print("状态码：", response.status_code)
                print(response.text[:1000])
                raise SystemExit

            data = response.json()
            month_bars.extend(data.get("bars", []))

            token = data.get("next_page_token")
            if not token:
                break

            params["page_token"] = token

        all_bars.extend(month_bars)

        print(f"{year}-{month:02d}：获取 {len(month_bars)} 条")
        time.sleep(0.2)

# 整理并保存
df = pd.DataFrame(all_bars)

if df.empty:
    print("没有获取到行情数据，请检查接口权限和返回结果。")
    raise SystemExit

df = df.rename(columns={
    "t": "timestamp",
    "o": "open",
    "h": "high",
    "l": "low",
    "c": "close",
    "v": "volume",
    "n": "trade_count",
    "vw": "vwap",
})

df["timestamp"] = pd.to_datetime(
    df["timestamp"], utc=True
)

df = (
    df.drop_duplicates(subset="timestamp")
      .sort_values("timestamp")
      .reset_index(drop=True)
)

df.to_csv(OUTPUT, index=False, encoding="utf-8-sig")

print("\n下载完成！")
print("行情总数：", len(df))
print("最早时间：", df["timestamp"].min())
print("最晚时间：", df["timestamp"].max())
print("保存位置：", OUTPUT)
