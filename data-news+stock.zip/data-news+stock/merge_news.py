
import pandas as pd
from pathlib import Path

# 自动定位当前项目文件夹
folder = Path(__file__).resolve().parent

# 两个原始文件
file_2022_2024 = folder / "nvda_news_2022_2024.csv"
file_2025 = folder / "nvda_news_2025.csv"

# 合并后的新文件
output_file = folder / "nvda_news_2022_2025.csv"

# 读取数据
df_old = pd.read_csv(file_2022_2024)
df_2025 = pd.read_csv(file_2025)

print("2022—2024 年新闻数量：", len(df_old))
print("2025 年新闻数量：", len(df_2025))

# 按照 2022—2024 在前、2025 在后的顺序合并
df = pd.concat(
    [df_old, df_2025],
    ignore_index=True,
    sort=False
)

# 按新闻时间排序，确保从早到晚排列
if "created_at" in df.columns:
    df["created_at"] = pd.to_datetime(
        df["created_at"], errors="coerce", utc=True
    )
    df = df.sort_values(
        "created_at", ascending=True, na_position="last"
    )

# 保存为新文件
df.to_csv(output_file, index=False, encoding="utf-8-sig")

print("\n合并完成！")
print("合并后新闻总数：", len(df))
print("合并后字段：", df.columns.tolist())
print("保存位置：", output_file)
