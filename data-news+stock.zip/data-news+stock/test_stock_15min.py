import os
import requests
from datetime import datetime, timezone

from getpass import getpass

API_KEY = getpass("请输入 Alpaca API Key: ")
API_SECRET = getpass("请输入 Alpaca Secret Key: ")


url = "https://data.alpaca.markets/v2/stocks/NVDA/bars"

params = {
    "timeframe": "15Min",
    "start": "2025-10-01T00:00:00Z",
    "end": "2025-10-03T23:59:59Z",
    "limit": 1000,
    "adjustment": "split",
    "feed": "iex",
    "sort": "asc",
}

headers = {
    "APCA-API-KEY-ID": API_KEY,
    "APCA-API-SECRET-KEY": API_SECRET,
}

response = requests.get(
    url, headers=headers, params=params, timeout=30
)

print("HTTP 状态码：", response.status_code)

if response.ok:
    data = response.json()
    bars = data.get("bars", [])

    print("获取到的 K 线数量：", len(bars))
    print("下一页 token：", data.get("next_page_token"))
    print("前 3 条数据：", bars[:3])
else:
    print("返回信息：", response.text[:1500])
