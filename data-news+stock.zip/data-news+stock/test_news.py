
import requests
import pandas as pd
from getpass import getpass
from pathlib import Path
from datetime import date
import time

# =========================
# 1. 输入 API 密钥
# =========================
API_KEY = getpass("请输入 Alpaca API Key: ")
API_SECRET = getpass("请输入 Alpaca Secret Key: ")

# =========================
# 2. 设置下载范围和保存位置
# =========================
URL = "https://data.alpaca.markets/v1beta1/news"

# 自动保存到 test_news.py 所在的文件夹
OUTPUT_FILE = Path(__file__).resolve().parent / "nvda_news_2025.csv"

HEADERS = {
    "APCA-API-KEY-ID": API_KEY,
    "APCA-API-SECRET-KEY": API_SECRET
}

# 如果之前有同名文件，重新开始下载
if OUTPUT_FILE.exists():
    OUTPUT_FILE.unlink()

all_count = 0

# 按月抓取，方便确认每个月的进度
for month in range(1, 13):
    start_date = date(2025, month, 1)

    if month == 12:
        end_date = date(2026, 1, 1)
    else:
        end_date = date(2025, month + 1, 1)

    # 使用左闭右开的月份区间
    start_time = f"{start_date.isoformat()}T00:00:00Z"
    end_time = f"{end_date.isoformat()}T00:00:00Z"

    print(f"\n正在获取 {month:02d} 月新闻……")

    page_token = None
    month_count = 0

    while True:
        params = {
            "symbols": "NVDA",
            "start": start_time,
            "end": end_time,
            "limit": 50,
            "sort": "asc",
            "include_content": "false"
        }

        if page_token:
            params["page_token"] = page_token

        try:
            response = requests.get(
                URL,
                headers=HEADERS,
                params=params,
                timeout=60
            )

            if response.status_code != 200:
                print("请求失败，HTTP 状态码：", response.status_code)
                print("服务器返回：", response.text[:1000])
                raise SystemExit(
                    "程序已停止。请检查错误信息，当前 CSV 可能不完整。"
                )

            data = response.json()
            articles = data.get("news", [])

            if not articles:
                break

            # 保留原始字段，并把股票代码列表转换成字符串
            rows = []
            for article in articles:
                row = article.copy()

                if isinstance(row.get("symbols"), list):
                    row["symbols"] = ",".join(row["symbols"])

                rows.append(row)

            page_df = pd.DataFrame(rows)

            # 每一页立即写入文件，避免中途退出丢失已下载内容
            page_df.to_csv(
                OUTPUT_FILE,
                mode="a",
                index=False,
                header=not OUTPUT_FILE.exists() or OUTPUT_FILE.stat().st_size == 0,
                encoding="utf-8-sig"
            )

            count = len(articles)
            month_count += count
            all_count += count

            print(
                f"  本页 {count} 条；"
                f"本月累计 {month_count} 条；"
                f"全年累计 {all_count} 条"
            )

            page_token = data.get("next_page_token")

            if not page_token:
                break

            # 稍微放慢请求，减少触发限流的概率
            time.sleep(0.2)

        except requests.RequestException as e:
            print("网络请求失败：", repr(e))
            raise SystemExit(
                "程序已停止。CSV 可能只包含部分数据，请勿当作完整数据使用。"
            )

    print(f"{month:02d} 月获取结束，共 {month_count} 条")

print("\n========== 下载结束 ==========")
print("全年累计获取：", all_count, "条")
print("文件保存位置：", OUTPUT_FILE)
print("注意：请核实每个月均正常完成后，再将文件用于研究。")
