
import requests
import pandas as pd
from getpass import getpass
from pathlib import Path
import time

API_KEY = getpass("请输入 Alpaca API Key: ")
API_SECRET = getpass("请输入 Alpaca Secret Key: ")

URL = "https://data.alpaca.markets/v1beta1/news"
OUTPUT_FILE = (
    Path(__file__).resolve().parent / "nvda_news_2022_2024.csv"
)

HEADERS = {
    "APCA-API-KEY-ID": API_KEY,
    "APCA-API-SECRET-KEY": API_SECRET
}

# 避免覆盖已经存在的文件
if OUTPUT_FILE.exists():
    print(f"目标文件已存在：{OUTPUT_FILE}")
    print("为避免覆盖，请先备份或删除旧文件，再重新运行。")
    raise SystemExit

total = 0

for year in range(2022, 2025):
    for month in range(1, 13):
        start = f"{year}-{month:02d}-01T00:00:00Z"

        if month == 12:
            end = f"{year + 1}-01-01T00:00:00Z"
        else:
            end = f"{year}-{month + 1:02d}-01T00:00:00Z"

        print(f"\n正在获取 {year} 年 {month:02d} 月新闻……")

        page_token = None
        month_count = 0

        while True:
            params = {
                "symbols": "NVDA",
                "start": start,
                "end": end,
                "limit": 50,
                "sort": "asc",
                "include_content": "false"
            }

            if page_token:
                params["page_token"] = page_token

            try:
                response = requests.get(
                    URL,
                    headers=HEADERS,
                    params=params,
                    timeout=60
                )

                if response.status_code == 429:
                    print("请求过于频繁，等待 10 秒后重试……")
                    time.sleep(10)
                    continue

                if response.status_code != 200:
                    print("HTTP 状态码：", response.status_code)
                    print("服务器返回：", response.text[:1000])
                    raise SystemExit(
                        "下载中止，当前文件可能不完整，请检查错误。"
                    )

                data = response.json()
                articles = data.get("news", [])

                if not articles:
                    break

                rows = []
                for article in articles:
                    row = article.copy()
                    if isinstance(row.get("symbols"), list):
                        row["symbols"] = ",".join(row["symbols"])
                    rows.append(row)

                page_df = pd.DataFrame(rows)
                page_df.to_csv(
                    OUTPUT_FILE,
                    mode="a",
                    index=False,
                    header=(
                        not OUTPUT_FILE.exists()
                        or OUTPUT_FILE.stat().st_size == 0
                    ),
                    encoding="utf-8-sig"
                )

                count = len(articles)
                month_count += count
                total += count

                print(
                    f"  本页 {count} 条；"
                    f"本月累计 {month_count} 条；"
                    f"累计 {total} 条"
                )

                page_token = data.get("next_page_token")
                if not page_token:
                    break

                time.sleep(0.3)

            except requests.RequestException as e:
                print("网络请求失败：", repr(e))
                raise SystemExit(
                    "下载中止，CSV 可能不完整，请检查后再继续。"
                )

        print(f"{year}-{month:02d} 获取结束：{month_count} 条")

print("\n========== 下载结束 ==========")
print("累计获取新闻：", total, "条")
print("保存位置：", OUTPUT_FILE)
print("请检查每个月的下载记录，再确认数据是否完整。")
